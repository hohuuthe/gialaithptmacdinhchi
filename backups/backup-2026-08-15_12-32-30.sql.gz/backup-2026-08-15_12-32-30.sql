--
-- PostgreSQL database dump
--

\restrict hvDfkQsRfCen7bE6THot43XInzrfaPILLqXqYGqgKjZ6khZgt0yisbhvBONCW6a

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."phancong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."namhoc";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."doanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Mọi người có thể xem tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."settings";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Mọi người có thể xem" ON "public"."github_settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."phancong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."namhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tuan_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tieu_chi_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nguoi_to_cao_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nam_hoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_doan_vien_vi_pham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "fk_thongbao_riengbiet_taikhoan";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "fk_thongbao_riengbiet_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_doanvien";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_baocao";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "fk_ql_baocao_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_tuan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_chidoan";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_optimization_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_sender";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_namhoc";
DROP INDEX IF EXISTS "public"."idx_thongbao_riengbiet_dates";
DROP INDEX IF EXISTS "public"."idx_theodoi360_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_theodoi360_doanvien";
DROP INDEX IF EXISTS "public"."idx_taikhoan_username_lower";
DROP INDEX IF EXISTS "public"."idx_taikhoan_role";
DROP INDEX IF EXISTS "public"."idx_taikhoan_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_optimization_namhoc";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_doanvien";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_chidoan";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_baocao";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thongke";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_hocky_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_lopcham_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_hocky";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chamlop";
DROP INDEX IF EXISTS "public"."idx_cauhinh_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_17" DROP CONSTRAINT IF EXISTS "messages_2026_08_17_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_16" DROP CONSTRAINT IF EXISTS "messages_2026_08_16_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_15" DROP CONSTRAINT IF EXISTS "messages_2026_08_15_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_14" DROP CONSTRAINT IF EXISTS "messages_2026_08_14_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_13" DROP CONSTRAINT IF EXISTS "messages_2026_08_13_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_12" DROP CONSTRAINT IF EXISTS "messages_2026_08_12_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_11" DROP CONSTRAINT IF EXISTS "messages_2026_08_11_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "unique_xet_thidua_chidoan_hocky";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "unique_chidoan_tuan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "unique_cauhinh_namhoc_hocky";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "thongbao_riengbiet_pkey";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_hethong" DROP CONSTRAINT IF EXISTS "thongbao_hethong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_pkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "ql_nop_bc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "ql_baocao_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_endpoint_key";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "gio_hoc_tap_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_17";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_16";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_15";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_14";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_13";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_12";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_11";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."xet_thidua";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."thongbao_riengbiet";
DROP TABLE IF EXISTS "public"."thongbao_hethong";
DROP TABLE IF EXISTS "public"."theodoi360";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ql_nop_bc";
DROP TABLE IF EXISTS "public"."ql_baocao";
DROP TABLE IF EXISTS "public"."push_subscriptions";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."gio_hoc_tap";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."cauhinh_tieuchi_xet_thidua";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]);
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "public"."get_secure_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_doanvien_id"();
DROP FUNCTION IF EXISTS "public"."get_auth_chidoan_id"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_realtime_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_realtime_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text",
	"negate" boolean
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_realtime_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql("text", "text", "jsonb", "jsonb"); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION "graphql_public"."graphql"("operationName" "text" DEFAULT NULL::"text", "query" "text" DEFAULT NULL::"text", "variables" "jsonb" DEFAULT NULL::"jsonb", "extensions" "jsonb" DEFAULT NULL::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") OWNER TO "supabase_admin";

--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: get_auth_chidoan_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_chidoan_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT chidoan_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_chidoan_id"() OWNER TO "postgres";

--
-- Name: get_auth_doanvien_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_doanvien_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT doanvien_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_doanvien_id"() OWNER TO "postgres";

--
-- Name: get_auth_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_role"() OWNER TO "postgres";

--
-- Name: get_secure_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_secure_role"() OWNER TO "postgres";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

--
-- Name: rpc_delete_auth_users_by_usernames("text"[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_uname text;
  v_safe text;
  v_emails text[] := '{}';
BEGIN
  IF p_usernames IS NULL OR array_length(p_usernames, 1) IS NULL THEN
    RETURN;
  END IF;

  FOREACH v_uname IN ARRAY p_usernames LOOP
    v_safe := lower(regexp_replace(v_uname, '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe <> '' THEN
      v_emails := array_append(v_emails, v_safe || '@htqltd.vn');
      v_emails := array_append(v_emails, v_safe || '@%');
    END IF;
  END LOOP;

  -- Xóa chính xác các người dùng tương ứng trong auth.users
  DELETE FROM auth.users WHERE email = ANY(v_emails) OR email ILIKE ANY(v_emails);
END;
$$;


ALTER FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "doanvien_id" "uuid",
    "sl_dangnhap" integer DEFAULT 0,
    "tg_truycap" timestamp with time zone
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT * FROM public.taikhoan 
  WHERE username = p_username 
  LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_realtime_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_realtime_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "custom_claims_allowlist" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."cauhinh_tieuchi_xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "ten_tieuchi_1" character varying(255) DEFAULT 'Tiêu chí 1'::character varying,
    "sudung_1" boolean DEFAULT true,
    "kieudulieu_1" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_2" character varying(255) DEFAULT 'Tiêu chí 2'::character varying,
    "sudung_2" boolean DEFAULT true,
    "kieudulieu_2" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_3" character varying(255) DEFAULT 'Tiêu chí 3'::character varying,
    "sudung_3" boolean DEFAULT true,
    "kieudulieu_3" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_4" character varying(255) DEFAULT 'Tiêu chí 4'::character varying,
    "sudung_4" boolean DEFAULT true,
    "kieudulieu_4" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_5" character varying(255) DEFAULT 'Tiêu chí 5'::character varying,
    "sudung_5" boolean DEFAULT true,
    "kieudulieu_5" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_6" character varying(255) DEFAULT 'Tiêu chí 6'::character varying,
    "sudung_6" boolean DEFAULT false,
    "kieudulieu_6" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_7" character varying(255) DEFAULT 'Tiêu chí 7'::character varying,
    "sudung_7" boolean DEFAULT false,
    "kieudulieu_7" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_8" character varying(255) DEFAULT 'Tiêu chí 8'::character varying,
    "sudung_8" boolean DEFAULT false,
    "kieudulieu_8" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_9" character varying(255) DEFAULT 'Tiêu chí 9'::character varying,
    "sudung_9" boolean DEFAULT false,
    "kieudulieu_9" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_10" character varying(255) DEFAULT 'Tiêu chí 10'::character varying,
    "sudung_10" boolean DEFAULT false,
    "kieudulieu_10" character varying(20) DEFAULT 'NUMBER'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "ghi_chu" "text",
    "giai_thich" "text",
    "trang_thai" character varying(30) DEFAULT 'dang_xet'::character varying,
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_10_check" CHECK ((("kieudulieu_10")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_1_check" CHECK ((("kieudulieu_1")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_2_check" CHECK ((("kieudulieu_2")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_3_check" CHECK ((("kieudulieu_3")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_4_check" CHECK ((("kieudulieu_4")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_5_check" CHECK ((("kieudulieu_5")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_6_check" CHECK ((("kieudulieu_6")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_7_check" CHECK ((("kieudulieu_7")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_8_check" CHECK ((("kieudulieu_8")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_9_check" CHECK ((("kieudulieu_9")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "chk_cauhinh_trang_thai" CHECK ((("trang_thai")::"text" = ANY ((ARRAY['dang_xet'::character varying, 'ban_du_thao'::character varying, 'ban_cong_bo'::character varying])::"text"[])))
);


ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: gio_hoc_tap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."gio_hoc_tap" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "so_tot" integer DEFAULT 0,
    "so_kha" integer DEFAULT 0,
    "so_tb" integer DEFAULT 0,
    "so_yeu" integer DEFAULT 0,
    "diem_tot_cauhinh" numeric DEFAULT 10,
    "diem_kha_cauhinh" numeric DEFAULT 7,
    "diem_tb_cauhinh" numeric DEFAULT 4,
    "diem_yeu_cauhinh" numeric DEFAULT 1,
    "diem_tb_hoc_tap" numeric(5,2) DEFAULT 0.00,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()),
    "hocky" "text"
);


ALTER TABLE "public"."gio_hoc_tap" OWNER TO "postgres";

--
-- Name: TABLE "gio_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."gio_hoc_tap" IS 'Bảng quản lý giờ học tập và điểm trung bình học tập của Chi đoàn theo tuần và năm học';


--
-- Name: COLUMN "gio_hoc_tap"."namhoc_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."namhoc_id" IS 'Liên kết với năm học hiện tại';


--
-- Name: COLUMN "gio_hoc_tap"."chidoan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."chidoan_id" IS 'Liên kết với Chi đoàn được xếp loại giờ học';


--
-- Name: COLUMN "gio_hoc_tap"."tuan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."tuan_id" IS 'Liên kết với tuần học tương ứng';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tot_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tot_cauhinh" IS 'Điểm cấu hình của giờ Tốt tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_kha_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_kha_cauhinh" IS 'Điểm cấu hình của giờ Khá tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_cauhinh" IS 'Điểm cấu hình của giờ Trung bình tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_yeu_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_yeu_cauhinh" IS 'Điểm cấu hình của giờ Yếu tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_hoc_tap" IS 'Điểm trung bình học tập thực tế cuối cùng của tuần';


--
-- Name: COLUMN "gio_hoc_tap"."hocky"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."hocky" IS 'Học kỳ diễn ra tuần học tập (ví dụ: HK1, HK2)';


--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "giai_thich" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."push_subscriptions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text",
    "chidoan_id" "uuid",
    "subscription" "jsonb" NOT NULL,
    "endpoint" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."push_subscriptions" OWNER TO "postgres";

--
-- Name: ql_baocao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_baocao" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "chu_de" "text" NOT NULL,
    "chu_de_phu" "text",
    "tu_ngay" "date",
    "den_ngay" "date",
    "cho_phep_minh_chung" boolean DEFAULT true,
    "doi_tuong_nop" "text",
    "huong_dan" "text",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "nam_hoc_id" "uuid",
    "hoc_ky" "text",
    "config_noi_dung1" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung2" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung3" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung4" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung5" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung6" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung7" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung8" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung9" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung10" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}'::"jsonb",
    "allowed_file_types" "text" DEFAULT 'image,video,pdf,doc'::"text",
    "max_file_size" integer DEFAULT 10
);


ALTER TABLE "public"."ql_baocao" OWNER TO "postgres";

--
-- Name: COLUMN "ql_baocao"."config_noi_dung1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung1" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 1';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung2" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 2';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung3" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 3';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung4" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 4';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung5"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung5" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 5';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung6"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung6" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 6';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung7"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung7" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 7';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung8"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung8" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 8';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung9"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung9" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 9';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung10"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung10" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 10';


--
-- Name: ql_nop_bc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_nop_bc" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ql_bao_cao_id" "uuid" NOT NULL,
    "doanvien_id" "uuid",
    "noi_dung1" "text",
    "noi_dung2" "text",
    "noi_dung3" "text",
    "noi_dung4" "text",
    "noi_dung5" "text",
    "noi_dung6" "text",
    "noi_dung7" "text",
    "noi_dung8" "text",
    "noi_dung9" "text",
    "noi_dung10" "text",
    "duong_dan_minh_chung" "text",
    "ghi_chu" "text",
    "trang_thai" "text",
    "ngay_capnhat" timestamp with time zone DEFAULT "now"(),
    "chi_doan_id" "uuid",
    "danh_sach_anh" "text",
    "vaitro_nop" "text",
    "doituong_nop" "text",
    "nguoi_tao_id" "text"
);


ALTER TABLE "public"."ql_nop_bc" OWNER TO "postgres";

--
-- Name: COLUMN "ql_nop_bc"."danh_sach_anh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_nop_bc"."danh_sach_anh" IS 'Danh sách liên kết các ảnh minh chứng tải lên R2, phân tách bằng dấu phẩy';


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "he_so_tru" numeric DEFAULT 1,
    "he_so_cong" numeric DEFAULT 1
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: COLUMN "qlchidoan"."he_so_tru"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_tru" IS 'Hệ số nhân điểm trừ riêng biệt cho từng Chi đoàn';


--
-- Name: COLUMN "qlchidoan"."he_so_cong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_cong" IS 'Hệ số nhân điểm cộng riêng biệt cho từng Chi đoàn';


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "cloudinary_cloud_name" "text",
    "cloudinary_upload_preset" "text",
    "cloudinary_api_key" "text",
    "cloudinary_api_secret" "text",
    "r2_account_id" "text",
    "r2_access_key_id" "text",
    "r2_secret_access_key" "text",
    "r2_bucket_name" "text",
    "r2_custom_domain" "text",
    "show_class_select_gvcn" "text" DEFAULT 'Không hiển thị'::"text",
    "diem_tot" numeric DEFAULT 10,
    "diem_kha" numeric DEFAULT 7,
    "diem_tb" numeric DEFAULT 4,
    "diem_yeu" numeric DEFAULT 1,
    "ti_trong_diem_tuan" numeric DEFAULT 50,
    "ti_trong_diem_hoc_tap" numeric DEFAULT 50
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: COLUMN "settings"."diem_tot"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tot" IS 'Điểm cấu hình mặc định cho giờ Tốt (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_kha"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_kha" IS 'Điểm cấu hình mặc định cho giờ Khá (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_tb"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tb" IS 'Điểm cấu hình mặc định cho giờ Trung bình (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_yeu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_yeu" IS 'Điểm cấu hình mặc định cho giờ Yếu (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."ti_trong_diem_tuan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_tuan" IS 'Tỉ trọng % đóng góp của điểm tuần (trừ vi phạm) vào tổng điểm thi đua chung';


--
-- Name: COLUMN "settings"."ti_trong_diem_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_hoc_tap" IS 'Tỉ trọng % đóng góp của điểm trung bình giờ học tập vào tổng điểm thi đua chung';


--
-- Name: theodoi360; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."theodoi360" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nguoi_to_cao_id" "uuid" NOT NULL,
    "doan_vien_vi_pham_id" "uuid" NOT NULL,
    "tieu_chi_id" "uuid" NOT NULL,
    "chi_tiet_vi_pham" "text",
    "danh_sach_hinh_anh" "jsonb" DEFAULT '[]'::"jsonb",
    "url_video" "text",
    "trang_thai" "text" DEFAULT 'cho_duyet'::"text",
    "nam_hoc_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "ngay_vi_pham" "date",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "hoc_ky" "text",
    "phan_hoi_bi_to_cao" "text",
    "phan_hoi_lop" "text",
    "minh_chung_drive" "text"
);


ALTER TABLE "public"."theodoi360" OWNER TO "postgres";

--
-- Name: thongbao_hethong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_hethong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "sender" "text" DEFAULT 'Hệ thống'::"text",
    "target_role" "text" DEFAULT 'all'::"text",
    "target_chidoan_id" "uuid",
    "target_user_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_hethong" OWNER TO "postgres";

--
-- Name: thongbao_riengbiet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_riengbiet" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "sender_id" "uuid" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_role" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "target_roles" "jsonb" DEFAULT '[]'::"jsonb",
    "target_chidoan_ids" "jsonb" DEFAULT '[]'::"jsonb",
    "start_at" timestamp with time zone DEFAULT "now"(),
    "end_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_riengbiet" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tong_diem_cham_tuan" numeric(10,2) DEFAULT 0,
    "tieuchi_1" "text" DEFAULT ''::"text",
    "tieuchi_2" "text" DEFAULT ''::"text",
    "tieuchi_3" "text" DEFAULT ''::"text",
    "tieuchi_4" "text" DEFAULT ''::"text",
    "tieuchi_5" "text" DEFAULT ''::"text",
    "tieuchi_6" "text" DEFAULT ''::"text",
    "tieuchi_7" "text" DEFAULT ''::"text",
    "tieuchi_8" "text" DEFAULT ''::"text",
    "tieuchi_9" "text" DEFAULT ''::"text",
    "tieuchi_10" "text" DEFAULT ''::"text",
    "tong_diem" numeric(10,2) DEFAULT 0,
    "xep_hang" integer,
    "danh_hieu_thi_dua" character varying(255) DEFAULT ''::character varying,
    "ghi_chu" "text" DEFAULT ''::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[])))
);


ALTER TABLE "public"."xet_thidua" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_11; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_11" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_11" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_12; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_12" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_12" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_13; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_13" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_13" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_14; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_14" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_14" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_15; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_15" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_15" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_16; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_16" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_16" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_17; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_17" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_17" OWNER TO "supabase_realtime_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone DEFAULT "now"()
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_08_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_11" FOR VALUES FROM ('2026-08-11 00:00:00') TO ('2026-08-12 00:00:00');


--
-- Name: messages_2026_08_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_12" FOR VALUES FROM ('2026-08-12 00:00:00') TO ('2026-08-13 00:00:00');


--
-- Name: messages_2026_08_13; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_13" FOR VALUES FROM ('2026-08-13 00:00:00') TO ('2026-08-14 00:00:00');


--
-- Name: messages_2026_08_14; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_14" FOR VALUES FROM ('2026-08-14 00:00:00') TO ('2026-08-15 00:00:00');


--
-- Name: messages_2026_08_15; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_15" FOR VALUES FROM ('2026-08-15 00:00:00') TO ('2026-08-16 00:00:00');


--
-- Name: messages_2026_08_16; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_16" FOR VALUES FROM ('2026-08-16 00:00:00') TO ('2026-08-17 00:00:00');


--
-- Name: messages_2026_08_17; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_17" FOR VALUES FROM ('2026-08-17 00:00:00') TO ('2026-08-18 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
0b77bbdd-92d3-4c48-8344-2e26a4b39f55	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	{"sub": "0b77bbdd-92d3-4c48-8344-2e26a4b39f55", "email": "admin@schmsk5ubbwwmtz.com", "email_verified": false, "phone_verified": false}	email	2026-08-08 09:18:04.27493+00	2026-08-08 09:18:04.274976+00	2026-08-08 09:18:04.274976+00	40627f91-1696-44a1-b7c6-f1089125dc27
867c561c-a16a-4027-b479-cc7c677c12ab	867c561c-a16a-4027-b479-cc7c677c12ab	{"sub": "867c561c-a16a-4027-b479-cc7c677c12ab", "email": "buicaokhadan@schmsk5ubbwwmtz.com", "email_verified": false, "phone_verified": false}	email	2026-08-11 13:25:44.792598+00	2026-08-11 13:25:44.792646+00	2026-08-11 13:25:44.792646+00	508575d8-0d95-489d-ba23-b83397b93f50
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
a6b994b3-80f9-44e4-bffd-2607573dcf68	2026-08-08 09:18:04.303027+00	2026-08-08 09:18:04.303027+00	password	a1efee19-6105-4cb3-b30d-4f1848b8a899
ae068481-905b-4666-8437-f981b90372c8	2026-08-08 10:04:46.42075+00	2026-08-08 10:04:46.42075+00	password	872452e2-ba84-415d-8e6f-b8627de8b9e0
9c16b941-aae0-4f33-bb2a-2738ee5d5124	2026-08-08 13:49:52.217981+00	2026-08-08 13:49:52.217981+00	password	559b36a8-c06d-44e9-8a68-e57f5ae5f0b3
0058af86-28db-4175-992f-a3e5809dad9c	2026-08-11 13:25:44.852293+00	2026-08-11 13:25:44.852293+00	password	c0233368-e11f-4f36-a7db-92611b831036
fcd7506c-b944-4f0e-bcec-558d4211da04	2026-08-14 01:04:12.663684+00	2026-08-14 01:04:12.663684+00	password	91ccc5a5-906a-45ed-bd77-a396b7b1eed2
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	1	jmrxc2wblzcj	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	f	2026-08-08 09:18:04.292919+00	2026-08-08 09:18:04.292919+00	\N	a6b994b3-80f9-44e4-bffd-2607573dcf68
00000000-0000-0000-0000-000000000000	2	u62zz62yh4ok	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	f	2026-08-08 10:04:46.395542+00	2026-08-08 10:04:46.395542+00	\N	ae068481-905b-4666-8437-f981b90372c8
00000000-0000-0000-0000-000000000000	3	u6eabbumveon	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-08 13:49:52.190026+00	2026-08-09 07:42:02.665417+00	\N	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	4	xvlvt7mfhjoi	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-09 07:42:02.674992+00	2026-08-09 08:40:38.520236+00	u6eabbumveon	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	5	7q4dmojcdyj3	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-09 08:40:38.527727+00	2026-08-10 08:18:51.461984+00	xvlvt7mfhjoi	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	6	ejbueexqdghs	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-10 08:18:51.478461+00	2026-08-10 09:17:14.09128+00	7q4dmojcdyj3	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	7	5bnwjyxqomzj	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-10 09:17:14.104656+00	2026-08-11 13:20:26.697125+00	ejbueexqdghs	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	8	nn2k7m7ww7ig	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	f	2026-08-11 13:20:26.708197+00	2026-08-11 13:20:26.708197+00	5bnwjyxqomzj	9c16b941-aae0-4f33-bb2a-2738ee5d5124
00000000-0000-0000-0000-000000000000	9	4fhemkt4xheh	867c561c-a16a-4027-b479-cc7c677c12ab	t	2026-08-11 13:25:44.828337+00	2026-08-11 14:24:21.903504+00	\N	0058af86-28db-4175-992f-a3e5809dad9c
00000000-0000-0000-0000-000000000000	10	62ygswryo2kq	867c561c-a16a-4027-b479-cc7c677c12ab	t	2026-08-11 14:24:21.916348+00	2026-08-14 01:03:45.367642+00	4fhemkt4xheh	0058af86-28db-4175-992f-a3e5809dad9c
00000000-0000-0000-0000-000000000000	11	ttdpqocv5bf7	867c561c-a16a-4027-b479-cc7c677c12ab	f	2026-08-14 01:03:45.389611+00	2026-08-14 01:03:45.389611+00	62ygswryo2kq	0058af86-28db-4175-992f-a3e5809dad9c
00000000-0000-0000-0000-000000000000	12	swesrzp7oovu	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-14 01:04:12.654062+00	2026-08-14 02:02:53.307879+00	\N	fcd7506c-b944-4f0e-bcec-558d4211da04
00000000-0000-0000-0000-000000000000	13	6hq3jxtcs52z	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	t	2026-08-14 02:02:53.321958+00	2026-08-14 03:01:36.509801+00	swesrzp7oovu	fcd7506c-b944-4f0e-bcec-558d4211da04
00000000-0000-0000-0000-000000000000	14	6znlqpjhtxsj	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	f	2026-08-14 03:01:36.521465+00	2026-08-14 03:01:36.521465+00	6hq3jxtcs52z	fcd7506c-b944-4f0e-bcec-558d4211da04
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
a6b994b3-80f9-44e4-bffd-2607573dcf68	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	2026-08-08 09:18:04.28675+00	2026-08-08 09:18:04.28675+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
ae068481-905b-4666-8437-f981b90372c8	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	2026-08-08 10:04:46.378992+00	2026-08-08 10:04:46.378992+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
9c16b941-aae0-4f33-bb2a-2738ee5d5124	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	2026-08-08 13:49:52.174464+00	2026-08-11 13:20:26.729723+00	\N	aal1	\N	2026-08-11 13:20:26.729617	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0	123.26.116.193	\N	\N	\N	\N	\N
0058af86-28db-4175-992f-a3e5809dad9c	867c561c-a16a-4027-b479-cc7c677c12ab	2026-08-11 13:25:44.811882+00	2026-08-14 01:03:45.413136+00	\N	aal1	\N	2026-08-14 01:03:45.413007	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0	171.251.238.207	\N	\N	\N	\N	\N
fcd7506c-b944-4f0e-bcec-558d4211da04	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	2026-08-14 01:04:12.648649+00	2026-08-14 03:01:36.540491+00	\N	aal1	\N	2026-08-14 03:01:36.540368	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0	171.251.238.207	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	867c561c-a16a-4027-b479-cc7c677c12ab	authenticated	authenticated	buicaokhadan@schmsk5ubbwwmtz.com	$2a$10$hDUItnkXzItdlsbbddXDCOr3JrWrVA/WZjirX8uN7oj7F1.jI90A6	2026-08-11 13:25:44.80026+00	\N		\N		\N			\N	2026-08-11 13:25:44.810596+00	{"provider": "email", "providers": ["email"]}	{"sub": "867c561c-a16a-4027-b479-cc7c677c12ab", "email": "buicaokhadan@schmsk5ubbwwmtz.com", "email_verified": true, "phone_verified": false}	\N	2026-08-11 13:25:44.752165+00	2026-08-14 01:03:45.399761+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	0b77bbdd-92d3-4c48-8344-2e26a4b39f55	authenticated	authenticated	admin@schmsk5ubbwwmtz.com	$2a$10$X8oluoZ9u3zauE.qogQFWeOsuYCZPQm7g6jn7vTBLK8nso4w2wsaq	2026-08-08 09:18:04.279668+00	\N		\N		\N			\N	2026-08-14 01:04:12.648548+00	{"provider": "email", "providers": ["email"]}	{"sub": "0b77bbdd-92d3-4c48-8344-2e26a4b39f55", "email": "admin@schmsk5ubbwwmtz.com", "email_verified": true, "phone_verified": false}	\N	2026-08-08 09:18:04.262551+00	2026-08-14 03:01:36.527916+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: cauhinh_tieuchi_xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cauhinh_tieuchi_xet_thidua" ("id", "namhoc_id", "hoc_ky", "ten_tieuchi_1", "sudung_1", "kieudulieu_1", "ten_tieuchi_2", "sudung_2", "kieudulieu_2", "ten_tieuchi_3", "sudung_3", "kieudulieu_3", "ten_tieuchi_4", "sudung_4", "kieudulieu_4", "ten_tieuchi_5", "sudung_5", "kieudulieu_5", "ten_tieuchi_6", "sudung_6", "kieudulieu_6", "ten_tieuchi_7", "sudung_7", "kieudulieu_7", "ten_tieuchi_8", "sudung_8", "kieudulieu_8", "ten_tieuchi_9", "sudung_9", "kieudulieu_9", "ten_tieuchi_10", "sudung_10", "kieudulieu_10", "created_at", "updated_at", "ghi_chu", "giai_thich", "trang_thai") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat") FROM stdin;
48369e02-77a9-4bed-8af1-3eb81e313697	LÊ BẢO AN	05/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
b1c7ba9e-2a1d-4e21-82ea-3ac5b50c531a	TRẦN NGỌC ÁNH	25/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
ebe0a715-4466-4477-80f1-6be307763903	NGUYỄN ĐÌNH BÌNH	08/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
7b8e2407-69e8-4062-8a09-9da2760a1088	ĐINH QUANG DUY	05/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
ffa7ac87-bd1c-4040-b5b7-ad428ad09b4a	NGUYỄN THÙY DƯƠNG	20/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
73b5937a-bbc4-4d09-a474-b1c873bc24f4	NGUYỄN HẢI ĐĂNG	03/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
36b66e4b-2b2a-49da-882b-e5724eb1aa9e	TRƯƠNG THỊ THU HẢO	05/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
bb3d5e1b-20a2-462f-987f-e3df78befb4f	MAI THẢO HÂN	07/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
41c38df4-81fa-4876-b074-ee9d0f216e0d	PHẠM HỒ BẢO HÂN	31/01/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
a0b48b51-fc42-4932-bf90-5bc8c6f6d950	ĐẶNG VŨ HOÀNG	03/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
a261bcc2-1d9e-4371-b70e-d98a321be74a	PHẠM ANH HUY	05/07/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
f1c7791a-cc7d-41a0-8897-5ee8b981b0fe	ĐẶNG VIỆT HƯNG	03/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
9278611d-d89f-4e6a-832b-8c127d5252ba	NGUYỄN QUANG HƯNG	30/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
66dad288-6954-4da9-87d9-7b29b399748b	NGUYỄN LÊ HOÀNG HỮU	16/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
031db995-ace0-4cb6-8798-9f2c21aab71a	NGUYỄN XUÂN KHÁNH	07/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
27e68a0a-4f7a-493f-bf90-4c76d1d34c1e	HUỲNH DƯƠNG MINH KHÔI	05/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
639b1d8e-077c-4355-abf6-4dd480d66bd2	NGUYỄN THANH KHÔI	19/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
b1c5a259-65ea-42fd-8c41-04172fa1e205	VÕ ĐÌNH HÀO KIỆT	23/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
ddf2e4f1-edad-4c83-b0f3-4574d0b1b8b6	TRẦN CAO LINH	07/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
22522fee-e6ea-476c-8868-4e83f9d15e03	NGUYỄN HỮU LONG	10/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
48f1fd28-98d9-4c8e-9bdf-cce51c1d6e37	TRẦN DUY LONG	18/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
86d42c1e-d0de-48f2-9695-e82d793401d9	VÕ THÀNH LONG	03/12/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
450498cf-5690-4d4b-ae3c-8f7698a477f6	NGUYỄN THỊ NGỌC LUYẾN	27/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
92553dc9-097e-4488-80f3-a4cb32a44543	ĐÕ NGUYỄN TUYẾT MAI	27/07/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
2ed296db-cebc-4327-a4b2-5745e0172eab	HUỲNH LÊ MINH	21/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
26df4306-90e3-4969-9511-e6e14327debd	LÊ HOÀNG BẢO MINH	31/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
bbe07744-6e7d-481e-b786-90cedcd7ea01	TRẦN BẢO NGUYÊN	25/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
b5e710ff-28de-43e3-949c-0890de436e3e	AN ANH HOÀNG PHONG	14/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
97b1413d-fcb5-4e06-b424-9b768dcfb692	TRẦN TRUNG PHONG	01/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
d0d29e72-70c2-484c-a5df-e374db108985	NGUYỄN MINH PHÚC	13/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
528d27fb-3e8c-4083-bddc-77228ed2afde	LÊ NGUYỄN NHƯ PHƯƠNG	25/07/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
4bb9e004-cc41-4d1e-a9fc-5d90d3de4a43	VŨ TÔ KHÁNH PHƯƠNG	21/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
766171db-8c48-4857-b9f2-974350dba1bd	PHẠM DUY QUÂN	03/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
64fd6706-90ab-44de-be1b-5b5568af22cc	PHẠM VĂN MINH QUỐC	29/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
103d6a1a-606f-4393-a3c1-b911d6e92bcd	ỨNG THÀNH TÂM	21/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
5f88ffb6-10eb-436e-b823-9d1834b54c9e	LÊ THỊ THU THẢO	06/05/2008	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
99886e00-1925-4c30-88c6-17cf3207c4d2	NGUYỄN THỊ PHƯƠNG THẢO	30/06/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
93176f64-a119-4ee1-a62d-de5a3904eadd	NGUYỄN QUỐC THẮNG	01/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
85ae9da3-2a12-4e32-9f07-c64ba1318da0	NGUYỄN LÊ KIỀU THƯ	12/03/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
ffa6729a-b562-4826-8973-1d06ecc3b5e7	NGUYỄN HOÀNG BẢO THY	18/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
e50d660c-081e-4ef3-b7fe-07cabd19b77a	BẠCH ĐÌNH TRÍ	17/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
727457d6-4c7d-4a81-b155-16bc7ba18c2c	NGUYỄN ĐÌNH MINH TRÍ	06/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
01fc4034-10e6-4025-95af-223fc69f3e7c	ĐẶNG NGỌC NHÃ TRÚC	19/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
0f18a774-587b-49f4-9649-a8d69db22c3f	NGUYỄN ĐỨC TRUNG	26/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
9586afad-a2a3-4211-8f0e-6a837fca9477	LÊ NGUYỄN THẢO VI	21/01/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
c854f296-ca1c-4ea2-9c26-38763450c95d	ĐÀO VĂN VINH	02/07/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:23:54.253365+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 14:23:54.253365+00
592e8d4c-c285-42ad-bfc1-9c4c40ec9405	Nguyễn Hoàng Bảo Anh	22/09/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
476657ea-de27-4337-b1c7-35c1e483be31	Nguyễn Thị Phương Anh	11/07/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
d1e8e9a5-66c1-4ac0-b878-d5ba025ad521	Tôn Nữ Ngọc Anh	04/12/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
e7ccbcfc-fdf2-48ca-853e-f65ed434d415	Trần Thị Hà Anh	10/07/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
acc76320-f6bf-4f52-9908-a63838fb92d3	Trần Thị Ngọc Bích	14/10/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
560fefe4-d6ba-4732-8788-ab340cfb55a1	Nguyễn Thị Huyền Chi	10/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
7800cbed-521e-42f6-9941-c25c4b35e6f8	Nguyễn Đặng Mỹ Duyên	02/07/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
8689ee30-2ada-4a31-91cf-df4d4f6f36d4	Hoàng Hồng Đạt	12/05/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
e4234876-60da-4a25-bd71-b747a58105bc	Nguyễn Hữu Tiến Đạt	13/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
c5bf37f8-a9e4-47ea-b3d7-ea1acaa898d4	Hà Anh Đức	03/10/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
17833ebd-ab4f-4d1f-8fd7-a5994c1ca0cc	Rơ Châm Four	30/04/2009	Nam	Gia rai	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
04f3c236-c3e8-45b1-8632-5d2bc488147c	Lê Thanh Hà	01/05/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
748a0b90-6b17-4fcd-8f9c-666a52659912	Rơ Lan Thu Hiền	08/02/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
1c9983b8-e093-46f3-ae33-4f01c2a077b5	Mạc Trung Hiếu	02/11/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
fe7222ad-0f2f-49bf-8d62-06f40cd1c625	Nguyễn Thanh Hoàng	13/11/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
1e655b98-6fff-434e-b5d6-226a2a19b1be	Nguyễn Vĩnh Huy	17/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
3ee2dfbb-b55d-4742-a75b-1c747e0e7fd1	Lê Thị Huyền	09/09/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
328180f1-141c-42df-ad59-0e1d0d0a44ef	Rơ Châm In	17/10/2009	Nữ	Gia rai	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
1673ee9e-53fd-464b-b15f-162cca11519d	Hồ Phước Kha	05/02/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
1f359b31-4c33-4bab-8c87-a4d8e8d47865	Phạm Quốc Khánh	06/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
1b136be6-4610-4207-8a50-abbf8d4618b4	Nguyễn Huỳnh Anh Khoa	20/11/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
c5698c37-99be-456d-85a9-7a23a47aa3ce	Siu Si La	04/12/2009	Nữ	Gia rai	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
99756e2a-51fc-4ccf-b177-b4f5e6699a49	Nguyễn Hoàng Mai Ly	20/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
cbd02033-8177-4df2-9e63-6bd5e759b207	Nguyễn Thị Thảo My	30/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
eed9c6c8-158e-4e39-961b-30c8e7ad531b	Nguyễn Phan Bảo Ngọc	04/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
082ab5ac-0a2c-412b-b9a9-49b5a6527cbf	Lê Bảo Nguyên	09/02/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
32bcf0d7-de2c-41a5-9a49-61ad138a59c3	Nguyễn Thị Thảo Nguyên	23/05/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
07d5c130-1389-44aa-93ac-a9b45378f452	VÕ MINH NGUYÊN	27/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
a34a60d3-c243-48d0-9b2b-602a235a627b	Nguyễn Long Nhật	26/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
61f06994-88b6-44cb-8bfc-d30e149b7f4c	Nguyễn Trần Long Nhật	18/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
f2d36988-e164-4340-a36b-93507da495f9	Trần Thùy Quỳnh Nhi	12/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
44dc401c-e1cd-4576-9eb0-26f8872fae38	Phạm Trần Tuyết Nhung	22/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
86b11ca0-c6a4-479e-b207-c7fbc11e447e	Đinh Trần Gia Như	14/06/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
45092491-0c80-448c-8e54-63a5a9fbdc0d	Mai Thị Uyển Như	02/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
ad4af767-9ca3-47f4-b226-e1419ad04aa6	Nguyễn Ngọc Gia Như	12/01/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
3e56a9aa-8fa7-4f62-a772-bb9a9af6713a	Trần Xuân Phi	01/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
c5909a1f-bbc6-4556-8bca-3084b23c859a	Nguyễn Mai Phương	13/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
a175b381-0a89-4e51-9cb8-e6a638cd2843	Trần Đoàn Gia Quy	16/01/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
20d4cdb8-510c-461e-95d2-eb8c33c5b5b3	Dương Thị Hoàng Quyên	07/09/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
cc1f71b6-4a3a-463b-9fa9-d917f62c620b	Ksor Saran	23/10/2009	Nữ	Gia rai	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
d4c3c285-3a49-4144-a2c7-9113a6711892	Nguyễn Duy Tân	17/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
3fc5b4cd-b52a-484d-bd51-a22c4ed7ab5b	Mã Ngọc Thành	08/07/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
3e6190e5-2afb-40fb-b874-9162f61a94fe	Bùi Đinh Anh Thiên	20/04/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
10c0496e-4a9c-4214-826f-ace1cf890a8a	Hà Thị Anh Thư	08/10/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
fc3a4526-3c74-4c8a-823c-550acc63c5ae	Hồ Anh Thư	07/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
dc6ca5ab-0d08-4793-9745-d19f2644cf4b	Phạm Xuân Tổng	07/11/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
a7d858cd-a356-406a-aee2-3733045f29f1	Vũ Thu Trang	12/11/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
64003b38-5e17-4ee3-95e8-4d9fa54bb361	Đoàn Nguyễn Phương Trúc	03/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
3cc9e6c6-9db1-4663-9f13-b8c64318000a	Trần Đức Tuấn Tú	25/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
c95323d9-a21a-4187-86a7-a85b99b7ea37	Tô Hoàng Minh Tuyến	28/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-08 14:32:39.035119+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	ead9dc42-f8d2-4959-a943-75da6fd02041	2026-08-08 14:32:39.035119+00
14272c8c-23e3-434c-9981-7366959c8e66	Hoàng Mỹ Anh	21/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
e926ff09-b5ee-4bc2-a74b-088219155f49	Kiều Vân Anh	25/05/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
85490b0c-0306-49a1-8346-24a7cc7cc2c0	Nguyễn Nhật Vân Anh	22/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
4392de40-e76f-4795-972a-312a428e62b3	Nguyễn Phạm Trâm Anh	03/01/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
78eb1d27-9872-4056-8643-c81e3b11dbd3	Phạm Gia Bảo	19/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
3d42b116-cc83-4697-acb2-ec34c5f45797	Nguyễn Phan Thành Chung	15/11/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
1fa0faa4-792c-454b-9299-fb09a52f21ec	Vũ Mạnh Cường	16/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
0ecaa083-2b76-4acc-9075-f2a01f16a33f	Hồ Dũng	20/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
61e548e8-eafb-486b-a1e0-974d94dc92b9	Trần Ngọc Bảo Hân	17/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
cfb5e1d5-13bc-4e7c-a671-a6db56016cae	Nguyễn Vũ Nhật Hoàng	22/05/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
051c6ffb-11a8-44a8-84c6-4ceba1ced612	Lê Trung Huấn	29/12/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
ae10775c-4217-4dbb-9ebb-9892d100395b	TRỊNH ĐÌNH KHANG	26/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
f5cab816-0716-4beb-b669-e5518335c4db	Nguyễn Ngọc Bảo Khánh	21/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
94aa4fc3-0797-406d-b64a-3eec13a841ce	Trương Thị Ngọc Mai	19/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
1a6ea4b3-96c6-458d-ac50-4058bcf50c61	Nguyễn Đoàn Hoài Nam	31/03/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
c534ccec-7d01-456a-9431-3d3f428065a8	Nguyễn Văn Ngọc	06/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
63968670-601e-4310-a8f9-b30c738f1b96	Nguyễn Vũ Anh Nguyên	28/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
0b46333b-4eab-4ede-a8a9-6076748f1fe3	Phạm Thị Tuyết Nhi	10/12/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
2c333c22-f05e-42a1-aed3-a685b32731d3	Lê Hà Hoàng Nhiên	09/09/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
557e43b1-aa09-4435-b2d6-6f84d14b20b1	Hoàng Nhã Vi Oanh	13/06/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
50bcbd13-78e1-46ff-b6be-371f41a3a493	Trần Ngọc Phát	30/11/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
0ef53ac5-f46d-48b0-b820-4f6500753300	Nguyễn Đình Phi	14/06/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
b100bfe7-fb33-4b49-b234-d7e03e340dd2	Đỗ Thanh Phong	21/07/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
43c13e46-b3eb-4460-b11a-cb6fb49316cd	Lê Thanh Quân	22/07/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
1077ac84-4822-4d87-8a54-3ef9b9e67715	Trần Ngọc Quý	19/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
2d538c22-7e0d-460a-92d7-5e5de3c1fc7b	Trần Đức Sang	07/12/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
9bb6a01c-37c6-4cdc-8328-dee5e2ad996d	Lê Ngọc Sơn	08/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
17dd68f8-414b-4897-b110-720ab90b9abc	Nguyễn Ngọc Sơn	23/09/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
e34a3053-dcd9-4da3-b031-75c0693b0a22	Lâm Ngọc Thạch	30/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
533acf37-1783-4647-a876-f0d7bdca024e	Nguyễn Thị Kim Thoa	08/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
b5be152b-c2a4-4502-8c6c-528e65138921	Chu Ngân Thương	30/03/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
4f527846-88de-4176-a2fa-52fc5ddd3a84	Phan Nguyễn Cao Thương	26/10/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
737ef94e-3a80-4b78-ba32-ab80f3dd0027	Phạm Văn Tình	23/04/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
b3bce47e-3328-4e19-8d52-e4025ac6e485	Nguyễn Thị Thùy Trang	08/05/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
9910d5c3-8e46-4c88-93d0-02a49518b887	Nguyễn Thanh Trực	06/02/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
2a85d051-9367-4921-8232-76ad27a6b385	Phan Thanh Trường	20/11/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
63da984c-4568-4b05-ab54-791d24c08e2e	Nguyễn Viết Trường Vũ	10/09/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
00add398-a3b7-46f7-a99c-1ad1fbe162b2	Phan Văn Vũ	28/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
9ef859fe-4de4-4def-8fe3-f1e4e6c981f9	Đặng Thành Vương	11/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
6c0c2983-0ab8-409b-9452-b5cf0e6e0073	Trần Thị Hà Vy	18/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
7c583281-1a6d-40de-ba21-acf098043a3e	Trương Yến Vy	09/07/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 07:50:58.48725+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-09 07:50:58.48725+00
039ca9a3-e20c-45c0-94af-d7397bdc8966	Chu Văn An	09/03/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
dc0398ce-e7be-4e39-b84c-041839101f60	Nguyễn Thị Vân Anh	18/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
4a06cad0-5fb4-4b24-87af-6d08e183e7c1	Trần Thiên Anh	29/08/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
cad5cfb6-2e32-437e-abf9-a8d8d5969481	Nguyễn Đình Quốc Bảo	02/02/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
abf81ed1-6d6e-41aa-b67e-bf0ba49e8611	VÕ THỊ BẢO CHÂU	12/10/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
3d1f7314-9b1e-4380-a68f-cb4487b9df34	Nguyễn Thị Ngọc Chiến	19/07/2008	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
4da91fbd-6205-4843-a214-47605c3e53a6	Châu Dương Nhật Diệu	11/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
a22f7d2e-c137-420e-9b29-7e5f0b5afc11	Trần Thị Mỹ Diệu	14/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
ae411494-b48e-4bb7-9c92-894ea69458a9	Hoàng Tiến Dũng	18/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
58429d9d-5bf9-4b66-b8b4-b9c71fcc755b	Nguyễn Tấn Hoàng Dũng	12/02/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
b36a5c34-8ec9-41f9-a46a-23bfad36d418	Nguyễn Viết Gia Huy	29/03/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
d89f6501-6e8d-49c6-883b-673eb174a425	Nguyễn Bùi Nguyên Khánh	14/10/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
a68742ff-ce4c-4de2-b1f1-d9ab0ee282a6	Phạm Đồng Khoa	09/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
5022e618-4463-4cf2-ba29-c1a801e847c3	Trần Thái Bảo Khương	22/06/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
57bec975-dd55-4074-9eae-5e6ce05e43ee	Lê Minh Kiên	09/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
276e121a-4100-4d4b-a268-b39be37415e7	Nguyễn Trung Kiên	18/11/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
1d4b5998-8456-44dc-bf18-7bd23d8d8923	Nguyễn Đắc  Mạnh	05/03/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
75d4b6ce-9d55-43eb-867f-f37a0c221eff	Đặng Gia Nghi	25/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
6af023c4-ec4f-4b18-bbae-01ec70631b7a	Nguyễn Bảo Ngọc	01/03/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
aaccd382-0c59-4816-8b03-d20ca885a0c3	Đặng Thị Yến Nhi	03/03/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
1b79e8ec-c0d4-4d3f-b08b-0d3c29c87872	Nguyễn Thị Thảo Nhi	02/03/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
76b8aae9-1630-41f3-882a-69e68f8c3649	Lê Sỹ Thành Phát	24/04/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
7c1a9457-aea3-49ea-a9f3-764d3567a02c	Lê Nguyễn Hoài Phương	02/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
3e4bb2f8-05fa-429a-80a2-8967aa5d2e13	Nguyễn Ngọc Thảo Quyên	26/02/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
5b9eac06-51ea-4aaa-a493-18c37b90064b	Nguyễn Ngọc Thạch	31/01/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
e5ee1f8a-cc15-4ee5-8533-0d163b97fe2b	Nguyễn Anh Thái	29/05/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
c41b34a9-7606-4999-a6c5-920b859bd801	Nguyễn Đình Thân	24/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
c1070e18-7025-4c95-b121-c1e9609bd1c6	Nguyễn Thị Thủy Tiên	02/04/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
0235d0b0-21da-4454-927b-4d68abbce741	Cao Văn Toàn	14/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
44f6a775-f452-4613-9eb8-139101046b0c	Nguyễn Thị Thu Trang	28/12/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
a438e91f-fae7-4ddb-b19b-25a920ab9dbc	Trần Thị Huyền Trang	09/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
7e0f3883-a21a-4492-9849-f216afc6b754	Nguyễn Hoàng Bảo Trân	18/10/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
22dce1eb-71f2-45a5-89cb-36aa2ab7e445	Trần Quang Trung	21/12/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
f388621d-977c-484a-84fd-3c30f2287883	Nguyễn Quang Trường	02/11/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
ec82e2e0-0cd0-42e7-baad-926ebe54efda	Nguyễn Thái Anh Tuân	30/11/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
53e75e54-d922-4ad3-87e0-b895a93190da	Nguyễn Huy Vũ	10/02/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
0c636376-6e86-4f8a-a7a5-5afd35dfd98e	Đỗ Bảo Vy	29/08/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
34d1a124-f9d1-4385-a29b-00a0ac91373b	Lê Ngọc Thuý Vy	09/01/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:03:55.928604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
4600a0d4-5e1d-4267-ad6b-70a670134276	Nguyễn Thị Kim Ánh	03/08/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
000cc243-010f-4259-936b-3e407271ee34	Võ Văn Chiến	16/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
8e38ddad-7385-4ecc-8514-d4e4a0e04708	Huỳnh Lê Tấn Dũng	17/05/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
906de53c-6436-4f7e-8103-63fe64d6fa0b	Trần Ngọc Đạt	22/04/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
764587ab-0b25-4e42-9b15-12a91837f593	Võ Văn Đạt	16/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
38fd2bcb-c77e-4697-8b2f-413570fdffe8	Trần Minh Đô	15/12/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
f68a8905-1f33-4988-87d5-97e866f69423	Rơ Châm H'sa	12/10/2009	Nữ	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
31d1bee8-8f38-41dd-b110-540742739dc7	Nguyễn Thanh Hải	27/10/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
b9bbf9b8-7562-48dd-89b4-cab8fecffc8e	Đỗ Nguyễn Gia Hân	31/05/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
4b9caff2-b97b-4987-add6-85c27b564baa	Bùi Huy Hoàng	18/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
9d45948f-1f05-41bc-9d10-ff11e62f6827	Lê Việt Hoàng	03/12/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
6c9cf672-82b7-4625-b922-140cfa0ed32d	Nguyễn Văn Hữu	20/12/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
719e3529-142d-4598-ba3e-555e71679c26	Trần Nguyễn Uyên Lê	23/01/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
46a4cbb0-7d66-4ff1-a348-885507419ecc	Lê Hoàng Long	25/10/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
d684a914-8a82-4996-85a9-0fbd3dbf95ee	Vũ La Thảo My	02/12/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
0c9fa1d5-68e1-456b-b9e5-9aa989ac643c	Mạc Dương Việt Nga	29/05/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
c6d2f6c0-68ae-401d-9589-92594dd9e216	Phùng Thị Khánh Ngọc	04/10/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
a80cf0b0-d7c3-4356-a98f-352e1e24272a	Lê Vinh Hoàng Quân	15/10/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
13d20df1-0688-478f-82f8-a50bc6370078	Nguyễn Thị Trúc Quyên	27/03/2009	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
4275e9ae-5ec5-490b-831b-8c9a54fdd9f3	Rơ Châm Rôm	22/03/2009	Nam	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
e071a17c-0fd2-48dd-b6ea-061bee473268	Rơ Châm Rứi	11/06/2008	Nam	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
f9332afc-5288-4dde-b96f-3fe7a1b383a7	Nguyễn Đức Sơn	13/03/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
16335e6d-0042-4c47-baaa-7ef227384135	Đỗ Văn Tài	24/05/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
3b1e826a-12d9-4ed1-9619-e4de3250230a	Nguyễn Thị Thanh Thảo	17/07/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
bd7320d0-4446-4118-9674-d879d69fafeb	Nguyễn Thị Hồng Thắm	20/12/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
6cfb0c6f-ac46-4160-9244-d944fc73631e	Nguyễn Hoàng Thiên Thư	28/07/2008	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
0d49d228-e546-4d17-8e9b-d5b1b57e85ae	Phạm Duy Tiến	27/08/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
1a5b8a5a-4686-4822-8996-5ddddc5f30b7	Phạm Công Tĩnh	31/12/2008	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
671f19f2-8d6c-4116-b426-d040fc007609	Đinh Mai Ánh Trúc	20/11/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
ce5e3dec-9a76-4f7b-ad17-c20c39ad5001	Quách Nguyễn Vũ Trường	26/05/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
bb993fa4-bde0-48a2-b038-8ce3f4288af1	Dương Lệ Kiều Vi	10/05/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
e01140cc-faf1-4a42-8f5b-1cd48cd48567	Rơ Châm Siu Vương	02/01/2009	Nam	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
800cb77f-2522-4290-8f2e-dd1f45095eb3	Huỳnh Thị Thảo Vy	10/06/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
aaf219b3-5f4d-444b-a84e-ba4e5a30cb8f	Vũ Thị Như Ý	09/02/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:14:03.161146+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-09 08:14:03.161146+00
7b25f111-9ab0-48a4-94b9-549dd307ea77	Y Chung	02/11/2009	Nam	Gia rai		f	\N	\N			2026-08-09 08:14:26.787583+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be		2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
ee326482-f689-4a4b-9e21-5393e94ed8f8	Ksor H Ruin	24/07/2009	Nam	Gia rai		f	\N	\N			2026-08-09 08:14:40.503974+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be		2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
11e283be-4633-45bb-bfbc-839203a7c118	Siu Wi	30/04/2009	Nữ	Gia rai		t	\N	\N			2026-08-09 08:15:00.161271+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be		2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-09 08:03:55.928604+00
5d8b59f1-d2c2-4a3a-9da3-0843b2625136	VŨ PHƯƠNG THÙY AN	11/05/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
d9bfe50a-841e-45a5-8377-ca3b93ac6ca7	DƯƠNG QUỲNH ANH	04/06/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
83a44971-4e7e-487c-852a-20867a546ca9	BÙI VŨ TRÂM ANH	07/08/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
7be47ffd-e191-4ec0-ac17-d9c0ff21bfed	NGUYỄN NHẬT ANH	04/05/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
37bbf19b-63f3-494a-bc4a-4f2141d339d5	TRỊNH QUỲNH ANH	20/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
6a417cab-4077-48e0-be69-0cd6c3ccaf52	BÙI CAO KHẢ DÂN	26/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
cb91134d-343c-46ef-a71b-cadeb7270998	ĐỖ VIỆT DŨNG	10/08/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
1ca94bac-78d4-4c14-8daf-c51b97da8704	NGUYỄN TRẦN XUÂN DŨNG	14/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
8bf7bff6-12bf-452d-9cc4-f18b855316e1	LÊ TRẦN BẢO DUY	06/06/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
6033ca2f-db5b-461f-8e44-e1dba461f61f	NGUYỄN TIẾN HẢI	15/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
f78b3155-084f-446b-8af0-15e03165562f	HUỲNH NHẬT BẢO HÂN	26/11/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
4ed6c5fc-38ab-424e-93bd-01b93edab589	HUỲNH THỊ NGỌC HIẾU	14/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
597e5ea9-f6ab-44c4-9b84-041262e21d8d	NGUYỄN ĐỨC HUY	15/05/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
b33c3d16-8189-4121-8ba3-aac6b31cf237	TRẦN ĐỨC HUY	16/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
a0b1ce6f-ddec-4f48-a148-682738a85cc0	NGUYỄN MINH KHANG	22/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
ee59870a-3adc-4a78-9b81-52071bb0385e	NGUYỄN VĨNH KHANG	17/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
f84fd2d2-d01b-46d1-b97b-381b93b1c4c9	PHẠM DUY KHANG	21/08/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
a63fb241-43fe-4a62-8e65-25947256b357	TRẦN NGỌC TÚ KHUÊ	17/12/2009	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
0596b8f9-133f-4727-a601-07ed9f24a19b	TRANG BẢO LINH	25/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
7d6734d8-807a-4b8f-9b01-5be10b599887	NGUYỄN ĐẮC MINH	11/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
06311517-ae28-4c6f-a273-494d94334610	ĐINH THỊ QUỲNH NGA	09/02/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
1f8229f9-a3ba-47bb-9797-47885bda47eb	Nguyễn Trần Bảo Nghi	21/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
691b45bd-0766-4311-86b3-32eeb22a725e	HUỲNH NHƯ BẢO NGỌC	17/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
84280e93-46ad-463f-9ca1-4daf7ef36d81	NGUYỄN BẢO NGỌC	06/05/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
5c58f10e-b477-4f2f-86ba-471070d82fcc	PHAN THỊ HỒNG NGỌC	24/02/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
9619bb72-6b4c-4d17-b279-369a8a43ad9b	TRẦN MINH NGỌC	26/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
41a85b8b-ccfc-496c-910d-657d5fecda38	VÕ THỊ BẢO NGỌC	21/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
e1add280-c489-4c24-aff2-55391bb6089e	ĐỖ THỊ THẢO NGUYÊN	15/02/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
92baec4a-71f3-4bba-81dd-2e7906b3d8b8	NGUYỄN TRẦN THẢO NGUYÊN	01/10/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
3b4067b7-34c8-463f-a216-3c439f108801	PHẠM TRÀ YẾN NHI	09/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
46a23fe3-7666-4c01-9e19-458a8b02e6ec	TRƯƠNG QUỲNH NHƯ	26/10/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
9d4a7781-bf2c-481c-b1a4-2a6f1d90a0a5	LÊ HUỲNH THẾ PHONG	03/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
889ecd6f-e5ee-40be-9b33-76ab73eeaf73	NGUYỄN XUÂN PHÚ	30/06/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
f2738caf-76df-4775-9ae3-3880bc08910d	NGUYỄN QUỲNH PHƯƠNG	31/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
da6324a2-512c-46ff-9f7a-b4a4825763ec	VÕ KIỀU NHÃ PHƯƠNG	05/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
b6b85d03-3506-4fa8-9790-056c6e1316f4	LÊ NGUYỄN ANH QUÂN	16/09/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
492eb955-d307-434f-bb88-4339ec0b3c9c	VÕ THỊ THANH THANH	17/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
be8c439f-8950-4e78-a8f7-89a7f4df0ac6	NGUYỄN THỊ THU THẢO	03/10/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
a2f2ab00-8814-4d04-b00a-4fda7a01a78c	NGUYỄN TRANG THẢO	08/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
740d3ac1-8fbe-47f3-b3a1-8c87c4e25460	DƯƠNG THỊ MỸ THƯ	02/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
1dd91cb7-b076-4da5-8d3a-4ab94dae1559	ĐÀO TRẦN ANH THƯ	04/06/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
fa8e89be-dd38-4ef8-be68-82d2dc933818	TRIỆU TẤN TIẾN	20/11/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
5840e272-927e-46ff-baee-485319e56906	LÊ QUÁCH THÙY TRANG	28/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
9d319e23-1472-4c57-8d54-de9a18ed5f3e	NGUYỄN THỊ NGỌC TƯỜNG	05/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
bbe9c9af-8e4f-44cb-a5d8-6d4407de5f6f	TRẦN HOÀNG THU UYÊN	02/06/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
f83dc4e9-cd20-4150-a0cd-2df28d4b1232	VŨ QUỐC VIỆT	24/06/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
b184fe79-36a4-442c-add1-ef7ec9b6cd07	NGUYỄN CÔNG VINH	30/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:22:09.400604+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-09 08:22:09.400604+00
5c237d8b-9b7e-44f1-bf44-2ffd8531b642	LÃ BẢO AN	25/05/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
3ef481d0-7151-4b80-b2be-578c50ee6429	NGUYỄN KHẮC CHIẾN	02/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
bb2d3a23-e4fe-4a2e-a907-71c321a8d6f7	NGUYỄN TẤN CƯỜNG	30/06/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
2f6b1347-0b71-43a2-b373-6d10935d8d3c	TRƯƠNG MỸ DỊU	26/12/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
5d833303-8025-46ab-8e32-ac40094d6afc	TRẦN TRỌNG ĐẠI	01/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
ac3bc769-0e11-4c6f-ab15-c0b48e26fc3c	NGUYỄN GIA ĐÔNG	25/08/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
c817fd2e-b51f-40d0-85e0-640ac7175984	RƠ CHÂM H'QUINH	23/07/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
7fded660-d229-4ccf-865e-8c89a5d55857	LÊ THIÊN HẠO	06/03/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
f83cdd8b-97e0-4b2a-a56d-95c729ddf4db	ĐỖ THỊ BÍCH HẰNG	02/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
168b6d53-3d01-4b02-bc67-3667f00348e8	ĐỖ THỊ MỸ HẰNG	28/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
61ec6560-afe3-4f49-8b23-f57553ce4c23	HUỲNH GIA HÂN	23/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
49fe16e7-8bc4-40b4-a463-3222bfb396b5	TRÀ THỊ DIỄM HÂN	07/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
d49f0a43-b375-4672-b56d-d83c6029bc13	NGUYỄN THỊ KIM HÒA	04/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
fdf7b27e-5ca9-4219-819b-f3931902f558	NGUYỄN QUỐC HOÀNH	29/03/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
d45e7ac8-6a97-4aeb-a0bc-41c239e13364	ĐÀO GIA HUY	10/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
f96205c9-17b7-475d-b172-cdfc43edfafe	PHẠM VĂN KHÁNH HUY	08/06/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
6b20daab-07b3-43e9-9edd-e6fbd0aa54f2	NGUYỄN TRÚC HUYỀN	20/08/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
f94a9bca-e813-440e-8059-d96a694e9eba	NGUYỄN ĐÌNH KHANG	27/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
9b815e61-b1a4-46be-b7b0-aee53c12f5b4	MAI TUẤN KIỆT	18/02/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
27293fcb-d048-4368-9807-fa12b780b53c	VÕ THỊ NHƯ LÝ	23/11/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
c59a6a80-8783-4fda-9989-552e184bcbf9	LÊ QUỲNH MAI	03/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
116c4ebf-0cf2-4f57-aa42-27ac5053ef71	ĐỖ QUANG MẠNH	24/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
4911a1eb-e2f3-495e-83d5-cb8bdacbe76d	TRẦN MINH	16/08/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
a8b3efa7-5dd6-455a-986c-3b9fc9262b11	LÊ THỊ TRÀ MY	24/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
9db4eb89-6968-4685-8ff6-7b37e21b832d	TRẦN THỊ THÚY NGA	27/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
39eabedd-546b-48e3-82d7-63ca238cb946	KIỀU PHƯƠNG NGUYÊN	19/05/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
0ce0a487-acc5-4c30-9b90-dbe1bf7fe047	NGUYỄN HOÀNG THỦY NGUYỆT	26/02/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
7f067173-5927-489b-8ad5-f19b983727ca	NGUYỄN HOÀNG NHẬT	15/06/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
8b5788d8-aab6-4166-a0cd-30c7268f656a	NGUYỄN HOÀNG PHÚC	16/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
191fc7f9-f3ea-4ea2-b03d-71089ad8a2b1	NGUYỄN NHẬT HOÀNG PHÚC	15/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
c34d3a64-5977-4268-a276-8343230377bf	NGUYỄN HUY QUÂN	16/10/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
daf4df5f-9f7e-4f63-95ce-a6bfb930af60	NGUYỄN KHẮC QUYẾT	02/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
3c592a8d-f984-4068-8c2c-6b17e13c6ee2	PHAN NGUYỄN NHƯ QUỲNH	24/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
6806a368-a269-47be-8ef5-98a552e6ba73	NGUYỄN THỊ PHƯƠNG THANH	18/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
4c3e43d6-4191-4436-ae3c-5d12e4592709	TRẦN VĂN THÀNH	27/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
32cb75ab-d55f-4bfa-b8ba-2f5c4f9dd85e	PHẠM HỮU THẮNG	09/04/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
75dfc1f0-15a6-4537-bb88-d8d8400e4c3f	NGUYỄN THÀNH THÔNG	30/05/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
cd62a504-ce53-467c-aaa8-e484bdd4a523	NGUYỄN HỮU THUẬN	30/05/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
073f40d9-1cb4-40a6-be86-4b5ac80acd4b	TRỊNH VĂN TIẾN	09/07/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
604953e6-3fda-4ca0-b8e5-39f6430af6b7	NGUYỄN CAO THÙY TRANG	20/10/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
87d417ec-02db-4850-986e-ff5c56def4ef	TRỊNH THỊ HUYỀN TRANG	20/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
e556f20c-4e45-43fc-91ff-406e9e0cb26c	NGUYỄN HỒNG BẢO TRÂN	11/12/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
13d65036-9ada-4af0-ac3f-61580c49b79b	VÕ NGỌC TRÍ	28/09/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
b7242bd4-9d05-4813-a7a0-b39b255d5555	LÊ HỒ THANH TRÚC	15/05/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
8e40e73d-f9ca-4c62-95c8-e085ce6ce913	PHAN TIẾN TÙNG	11/05/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
9419dcfc-7d63-4c91-8ada-7257f5f5387a	LÊ VĂN AN TƯỜNG	22/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
e87fae42-a6bd-44cf-a8a7-6bd96d4d5c11	HOÀNG ANH VŨ	02/11/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:24:47.583186+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-09 08:24:47.583186+00
cd5c4f2d-959c-4010-aa9a-04e5811e5176	NGUYỄN CÔNG BẢO	24/01/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
40530424-c96e-4a1d-b855-b217fc9b57e0	NGUYỄN THỊ NGỌC CHI	20/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
1b70281b-d27a-423a-b6f8-1c4a3f191cc5	NGUYỄN THỊ KIỀU DIỄM	23/07/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
506096c5-75fa-40f3-8cb1-d6781131ccf1	PHẠM THẾ DŨNG	31/01/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
98d10988-4054-479a-9ef5-f45af653c2f5	PHẠM NGỌC THÙY DUYÊN	31/03/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
ab33226e-7424-44db-867d-7c6c10e39d15	LÊ THỊ THÙY DƯƠNG	27/12/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
b5f7cd5d-76ec-4fe7-8d65-afba7e756f3c	TRẦN ANH ĐỨC	16/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
8dc8fd42-8795-4848-8c34-8776b31b6e57	VƯƠNG KIỀU KHẮC GHI	04/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
61c5ee54-5110-44c9-8f92-d812d76819e6	NGUYỄN THÀNH LONG GIANG	11/05/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
b820dc5f-cc47-470c-9d18-30bbc8e6b2d2	TRƯƠNG THỊ HỒNG HÀ	22/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
8706e300-0262-4de8-863c-aa62d69091ae	TRẦN THỊ THANH HẬU	29/08/2010	Nữ	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
cf04e9d7-3f7c-4f98-bbf9-7797ba7fe3fc	ĐINH TRỌNG HIẾU	18/11/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
0c89ae93-f9c8-4610-8c91-d6df23fc0d02	HOÀNG QUỐC HOA	02/04/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
7140cd71-7bff-407b-b1eb-73aca791a3c9	ĐÀO ĐỨC HOÀNG	14/01/2008	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
e3a0a689-4142-4920-a2c3-132e8e226498	VŨ HUY HOÀNG	21/07/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
9329a1d9-eb38-4259-accf-5f50c6bb4a39	LÂM CHẤN KHANG	22/09/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
fbf55540-8ba4-49ba-8e0a-32b2e4674559	NGUYỄN PHẠM THÁI KHANG	09/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
e452e8db-9a74-4edb-b92f-16616e4d483b	NGUYỄN MINH KHÔI	18/12/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
bad1785d-4d14-4f6f-ad8e-100ceeb87085	ĐỖ THỊ LAN	09/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
9779cd3d-1aff-40c5-a5e2-56810d2a8695	HUỲNH ĐẶNG KIM LINH	15/07/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
a404e0db-f9a1-47cf-917d-81af82489e43	ĐINH THÙY LINH	02/07/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
2f98a276-f4f2-4e8e-96b4-a590200d8674	TRƯƠNG NGUYỄN THÙY LINH	07/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
22d0db71-66ad-4b5a-bbcd-e3c26f574507	NGUYỄN XUÂN LỘC	03/06/2009	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
cddf3b8f-8977-409e-bcff-76f3565566f0	TRẦN ĐỨC LƯƠNG	11/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
5d578a91-685c-4e3e-bf7d-bcee8e3f3878	ĐÀO ĐẶNG HIỀN MINH	09/10/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
e76569bb-779a-4f40-84df-fd42ef2c7548	TRẦN THỊ HÀ MY	20/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
6ecf55d8-88ca-46fb-ab2d-0b187bf340f5	NGUYỄN BẢO NGỌC	18/11/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
8c3e36ae-c09a-4c7a-b0c6-4fc5c12b03b7	TRƯƠNG THỊ HỒNG NGỌC	22/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
f056b330-3629-4f38-9235-9c841f2be84e	THÂN ĐÌNH NGUYÊN	15/08/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
955e3bf2-d073-4900-9702-a980d60074f5	NGUYỄN ĐĂNG NHẬT	02/07/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
9223a770-b8c3-4acb-875b-f160ce9c0035	NGUYỄN THÁI BẢO NHẬT	01/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
949ad0b4-3995-47ad-9162-54568496e7e8	NGUYỄN THỊ YẾN NHI	08/05/2010	Nữ	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
d0f6b77a-95cc-42fa-8fd9-4d0f3e636ca3	LÊ THỊ TÂM NHƯ	04/06/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
6d69fd19-e245-463d-b167-de3c3eea0ac6	NGUYỄN TRẦN TÂM NHƯ	16/02/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
c85a6716-f6ff-4983-8a21-ccd686c20602	LÊ TRỌNG PHÚC	12/08/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
64f2ff33-a7d0-4224-af0d-d0365056faaf	NGUYỄN LƯƠNG PHÚC	03/12/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
ca7ae0d7-b95a-481e-b71a-fb7e71b4f219	BÙI PHI VŨ NHẬT TÂN	02/08/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
8c9b864f-bad9-4ddd-b1f1-fc14fe4d84f6	BÙI NGỌC THANH THẢO	01/07/2010	Nữ	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
165f9a1a-e9b4-456d-a04c-49ed3e34893b	NGUYỄN LÊ TẤT THẮNG	03/02/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
0f31cd0d-9be8-46a2-bd5b-03e6b7a3cca3	NGUYỄN THỊ MINH THI	15/12/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
7f6c13e9-fd4b-4f43-bb33-52f1fff7b5da	CAO VĂN TOÀN	12/02/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
3095d171-314a-4fd1-a2ab-2ef414dc8e49	LÊ NGỌC BẢO TRÂN	22/11/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
10770f77-a237-4089-80a4-4b56754515eb	ĐỖ VIẾT TRƯỞNG	01/03/2010	Nam	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
d9d60eca-eaf0-48c2-a138-9c731e765958	LÊ MINH TÚ	28/01/2010	Nam	kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
204a67d9-0316-4a44-aadc-c2c116b0d11a	THÁI NGUYỄN THANH TUYỀN	13/09/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
c957f62e-f60a-4e44-9004-7531fdb7d7fe	LÊ ĐÀO NHÃ UYÊN	10/11/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
4396878e-71de-4b85-a72d-b75ecd6eb179	RƠ CHÂM VIÊNG	07/03/2010	Nữ	Gia rai	\N	f	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
e92d1722-74f8-427f-b7c9-12de6364344d	TRẦN THỊ THẢO VY	30/01/2010	Nữ	kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:26:55.90592+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	1a901841-c865-4075-b751-709e6e07fc24	2026-08-09 08:26:55.90592+00
402185a5-14d8-4ecd-9d05-13a16673bcd7	NGUYỄN HÀ ANH	23/02/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
0fa8809f-615a-48db-b1ab-a3a730ef493a	BÙI THỊ TRÂM ANH	19/09/2009	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2fd0bd5c-901e-4bf0-9223-d4054f88048e	LƯƠNG LƯU TUẤN ANH	23/08/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
8043e1f2-38ae-4bbb-bed7-f31f21a79c4a	PHẠM TẤN BẢO	16/05/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
96c92781-325e-46a3-82ac-00dcff31b92c	TRƯƠNG NGUYỄN GIA BẢO	27/11/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
a5dfd808-773e-4f11-9e50-dca308552bf7	NGUYỄN THỊ NGỌC DIỆP	20/02/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
baafed12-b1a7-4340-a8fd-c9d11acd4ef7	NGUYỄN ĐẶNG HUYỀN DIỆU	04/10/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
0067148e-7d56-478b-9107-3c3db9c7e05f	LÊ THỊ KHÁNH DUYÊN	11/01/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
7196bb82-20fa-4ef7-91f4-3b90ba0c146a	NGUYỄN THANH ĐAN	09/12/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
f4194f8b-6298-47bd-abbf-19c55df072e9	KSOR H'PHƯƠNG	08/10/2009	Nữ	Gia rai	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
1f847a21-9d98-4259-ab62-3d8f4e9f80bc	TRẦN MỸ HẠNH	27/05/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
6c744241-1fe9-4f26-aa9e-455e5f45c01c	NGUYỄN THỊ HIÊN	25/05/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
1f044f34-21f6-4fc5-b236-223bd1e0a740	ĐẶNG QUANG HIẾU	27/05/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
76bb566b-3162-44f0-b832-a516e44696ff	NGUYỄN QUANG BẢO HOÀNG	01/01/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
95bc3aca-66e8-46a7-a8dd-3431736b4271	NGUYỄN TRUNG HUY	25/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2d8fbc66-4e53-414a-8781-e935cc6e35b9	TRẦN NGỌC KHOA	12/07/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2699b05d-c5e1-48d2-a3f3-ac2c86223937	NGUYỄN TRUNG KIÊN	27/05/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
856c2fe6-fd52-41a0-80db-557c26f3530b	PHẠM KHÁNH LINH	31/08/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
f02e4729-f025-4a29-93b6-a5df8e9953fb	TRƯƠNG ÁI LINH	21/12/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
4dab374d-d9bd-4859-a9e7-c646c296a228	TRƯƠNG THỊ MẪN MẪN	13/07/2010	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
d004c964-712c-4ab9-8cde-5bfb79dd2c5d	NGUYỄN BẢO NAM	28/06/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
0789a182-b052-4843-a5ae-10d27669de2a	TRẦN THỊ THẢO NGUYÊN	09/10/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2e54a5b5-a77b-4367-b2b3-6f7422c31f83	VÕ LÂM NHẬT	14/01/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
b9a4112c-3def-4a04-a3ac-896e43765eea	HỒ YẾN NHI	22/11/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
52487010-23d1-4ebc-83fe-82c228f91868	TRẦN THỊ NHUNG	25/01/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
f48e1af8-8793-4c08-8b37-4e4d6ab59101	MAI THỊ NHƯ	16/03/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
f8d72466-fad4-4ce7-a738-94a8b8f5156f	PHAN TOÀN TIẾN PHÁT	03/12/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
749bba9d-aac4-49d1-9899-b0e486d97340	VÕ NGỌC PHÚC	21/09/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2b65fbe3-fac8-4d98-b743-b1103f7bade5	ĐỖ THUYỀN QUYÊN	20/10/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
30e3ce90-38d0-4815-ba2a-2266fcb81e55	HOÀNG VÕ NHƯ QUỲNH	22/11/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
63494990-f6b9-415f-ad0e-6ac43188b1c9	HUỲNH LÊ NHƯ QUỲNH	25/09/2010	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
6b73e6b7-1b6b-444f-a7f2-04377f114413	LÊ THỊ DIỄM QUỲNH	30/06/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
5e44e30b-e046-47b8-8931-56a097af32c7	TRẦN THỊ DIỄM QUỲNH	29/12/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
9f9dae6c-234c-4b16-80a3-73d8f1849dd3	SOAN	25/06/2010	Nữ	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
3e7622c3-c49f-4a3b-afd3-f450532390c6	NGUYỄN PHAN DUY TÂM	03/06/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
64c31c77-a3ae-4c17-8d5f-97aed9a1ba72	NGUYỄN VÂN THƯ	28/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
5ed3ce0f-94a5-4143-8279-2ac3e214b0f4	LÊ TRẦN HOÀNG TRANG	18/06/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
d1341982-d1c3-4757-972f-922015551695	DƯƠNG THỊ MỸ TRÂM	22/11/2010	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
cbaf207c-7e83-41f4-b8c6-cddef2346a26	TRẦN THỊ THANH TRÚC	24/03/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
224d1c76-e91e-4674-95d2-1badbb1985b2	ĐẶNG NGỌC TÚ	14/05/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2a5dc32b-c5f8-4801-8dde-94f46b294222	ĐÀO THỊ THẢO VY	12/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
2b4e8f6c-656d-41de-b5f8-8177f48c92e7	NGUYỄN NGỌC KIỀU VY	30/07/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
a638884f-ed31-4f65-9908-0c4b061a2562	A YẾN	06/07/2010	Nữ	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:37:22.084322+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-09 08:37:22.084322+00
79e7cb29-0ed9-4608-a2f3-af5134404c3d	NGUYỄN THANH AN	30/01/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
8c9d87e2-a3ec-4672-b1fd-0225b58d78a2	TRƯƠNG VIỆT ANH	12/12/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
04d57b6e-75fc-4551-a5ad-8ca47403aedd	NGUYỄN KIỀU THIÊN ÂN	18/09/2010	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
b97e41da-9738-4885-ad2f-60c89cd04b1f	HỒ Y -THIÊN BẢO	21/05/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
0777583d-1e9a-4a4a-aeb8-2f13f5180bd7	RƠ CHÂM BYIÊN	09/02/2010	Nữ	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
aa105969-e27d-4b18-a22d-de4f6f7b8208	RƠ CHÂM CHIÊN	04/01/2010	Nam	Gia rai	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
10badace-510f-43c5-b79c-5be0597ff75d	NGUYỄN ĐẶNG ĐỨC CƯỜNG	11/11/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
7e4846f9-5bc2-430f-a19e-2efbdff3b159	ĐÀO VĂN TIẾN DỤNG	22/04/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
5c93348f-bac5-49e7-87c9-2a810182dc99	LÂM TRÚC ĐAN	23/07/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
ecac0647-e8f3-4845-8516-bda5f62d49dc	ĐÀO VĂN TIẾN ĐẠT	22/04/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
40130e60-1a08-4599-82b7-913ea05e9532	VŨ TIẾN HỒNG ĐỨC	18/06/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
5e6eeedc-ec69-4c45-aa34-2c00088f4255	RƠ CHÂM HANH	10/11/2010	Nữ	Gia rai	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
1197a448-0291-4716-a5b2-9745260b9a20	DƯƠNG QUANG HẠNH	15/01/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
fd4250be-f86f-47c2-977e-fb9d674197d5	NGUYỄN TRUNG HIẾU	04/01/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
1d7c0289-4a10-4ad8-8cd4-9013da5c75b4	NGUYỄN THỊ VŨ HOÀNG	04/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
ba91dc16-9693-45e3-b8b0-456c744e2c35	NGUYỄN DUY KHANG	14/10/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
35ab4fb9-e44c-4297-8751-1011aac5a077	KSOR MÊ KI	01/01/2010	Nam	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
b5db40bb-190b-4601-9b2d-d6c2a841a355	PHAN THÙY LÂM	25/04/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
b2e08bff-e263-491e-9b4e-f914273df76a	K PĂ LIÊN	15/09/2010	Nữ	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
99aed4ee-5c21-4dea-89d3-195c121513ec	TRƯƠNG HOÀNG LINH	09/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
f210734f-d16b-49a7-bb68-9041b3e584f1	PHẠM MAI NGÂN	03/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
59434340-2fdc-47df-a068-fde7d1bd21bc	NGUYỄN VĂN NHƯ NGUYỆN	25/09/2009	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
4b56c728-a81f-41e5-91bf-c8f2771c6f6c	CHU THỊ THANH NHÀN	27/04/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
b0266b71-ca8e-446c-865a-66678d056c23	NGUYỄN PHƯƠNG NHI	07/11/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
97ac60dc-dbea-4be7-907f-ffcd481b32cd	LÂM TÂM NHƯ	24/03/2010	Nữ	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
7a75c574-51c0-410b-8ab3-b2e7aa153f0e	LÊ YẾN NHƯ	03/01/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
eda521f7-d6c6-482f-a0ec-542014ac6e4e	NGUYỄN TẤN PHÁT	06/01/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
de87f908-5ad3-47fd-a606-5bc28e597fc0	TRƯƠNG THANH PHONG	29/11/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
71885386-d7c5-467b-be3a-2d436739952d	LÊ NGUYỄN NHƯ QUỲNH	18/09/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
0bfcfd95-9f64-409b-b167-c24b8cf73471	MAI THANH TÂM	04/05/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
972c035c-d6ef-4f7e-b215-3627bcea06ff	RƠ CHÂM THAN	10/10/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
e0105547-3573-422b-bbc5-65ba38eb4fff	H' THƠM	28/03/2010	Nữ	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
e1933bdc-7f0c-4dff-9536-7702327913d4	NGUYỄN HƯƠNG THỦY	11/02/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
46986821-2d89-4b8d-b64d-5b3fb028314f	PHẠM THỊ MINH THƯ	22/03/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
4d00444e-7931-41e2-bc7b-e22eadbf6ab2	PHAN NGUYỄN THANH TỊNH	31/08/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
8679e7fb-8e69-4223-aa82-59cd59c00db6	ĐẶNG THANH TRIỆU	18/02/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
14a2e8ff-b722-473e-8a40-cf1dd773c059	VÕ THANH TÚ	30/06/2009	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
fede6793-9ba2-4eb5-b65f-213837fefd9f	A HỒNG TUYẾT	08/02/2010	Nữ	Ba na	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
2dd8eccc-fae2-4ba1-a933-32a1df0cb8a5	VÕ LÊ PHƯƠNG UYÊN	19/10/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
226c9e29-c6cf-4e85-8df3-354a87d8963f	TRẦN HOÀNG VIỆT	04/03/2010	Nam	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
7feea97d-2339-4f15-983e-d00caaadd172	NGUYỄN QUANG VINH	31/03/2010	Nam	Kinh	\N	f	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
fe11307d-0f50-4e92-adbc-abcd8a76585c	LÊ THỊ KIỀU VY	31/10/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
894f5d71-01c2-4b08-b44e-8983998442c3	NGUYỄN PHẠM HẢI YẾN	10/05/2010	Nữ	Kinh	\N	t	\N	\N	\N	\N	2026-08-09 08:52:40.284989+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	\N	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-09 08:52:40.284989+00
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
865a56d8-dd71-4609-9b6b-f4859bfa64c8	139	2026-08-08 08:45:00.85378+00	2026-08-08 08:45:00.85378+00	2026-08-15 12:21:50.386987+00
\.


--
-- Data for Name: gio_hoc_tap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."gio_hoc_tap" ("id", "namhoc_id", "chidoan_id", "tuan_id", "so_tot", "so_kha", "so_tb", "so_yeu", "diem_tot_cauhinh", "diem_kha_cauhinh", "diem_tb_cauhinh", "diem_yeu_cauhinh", "diem_tb_hoc_tap", "updated_at", "hocky") FROM stdin;
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
project_02	congty/du_an_backend	main	supabase-backup.yml	supabase-restore.yml	ghp_abc123...	2026-08-08 08:45:00.85378+00	\N	2026-08-08 08:45:00.85378+00	2026-08-08 08:45:00.85378+00
default	hohuuthe/gialaithptmacdinhchi	main	supabase-backup.yml	supabase-restore.yml	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	2026-08-08 10:17:38.749+00	Admin	2026-08-08 10:10:11.575524+00	2026-08-08 10:17:37.730102+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-2027	f	2026-08-08 10:02:00.689154+00	2026-08-08 10:02:00.689154+00	f
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
d2e5fa46-ce2d-42ba-9969-5a71fb94b7c4	HK1	1	9415a0de-ce74-44f1-8ab1-3363150d20e0	c5811224-0c82-4f88-b226-de43be7e3ba3	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
7df32cec-348b-4166-8806-7101efed95e3	HK1	1	c5811224-0c82-4f88-b226-de43be7e3ba3	3e148a67-e9e3-4c3b-8053-5f3760d91f6a	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
4816aef6-6db6-4734-a61b-b7fb4bb01b10	HK1	1	3e148a67-e9e3-4c3b-8053-5f3760d91f6a	67610cc7-fc8d-427f-a761-a287e6684a68	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
fbd9901b-8e3e-4ee7-abb3-6ca4ed8c5fe5	HK1	1	67610cc7-fc8d-427f-a761-a287e6684a68	b7129033-6e18-42fa-ba97-0583d1dab51a	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
6a742ffd-48c7-429b-b380-8e88df656860	HK1	1	b7129033-6e18-42fa-ba97-0583d1dab51a	47ebde83-9919-4bee-919c-05f26d5462c9	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
1301b99e-e6f6-4f27-bcb5-2939d39041ab	HK1	1	47ebde83-9919-4bee-919c-05f26d5462c9	03185d94-5054-4656-a38e-0dfeea80e000	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
3c069ae6-acb7-4950-981a-043109418040	HK1	1	03185d94-5054-4656-a38e-0dfeea80e000	d4b09703-b71d-43f4-8bf8-8113993d052c	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
6c79bd29-481a-4ca0-a1b5-4472cd63ed7e	HK1	1	8bab981f-6595-422a-8ef8-531a8ad2dc6c	c833c350-b573-4008-8408-dc3246bfbf57	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
da23bd10-5d84-4d6e-8900-a3434c282e68	HK1	1	c833c350-b573-4008-8408-dc3246bfbf57	1a901841-c865-4075-b751-709e6e07fc24	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
7e07d6c6-b33d-4f87-b9e6-906b57b908d2	HK1	1	1a901841-c865-4075-b751-709e6e07fc24	65afb55f-0a15-49b8-b3a0-e854ca89c6c9	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
c037a84e-6123-4e56-910b-ddb5695cb362	HK1	1	65afb55f-0a15-49b8-b3a0-e854ca89c6c9	5a5d6f62-ea63-40dc-a979-41deb2a4b128	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
7bcb4916-a0d4-48b8-9da3-27b71716b5d8	HK1	1	5a5d6f62-ea63-40dc-a979-41deb2a4b128	cfe67912-0227-4c03-a869-f3c4d86cca8a	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
387e2595-633a-42d3-948d-58da7a8d74af	HK1	1	cfe67912-0227-4c03-a869-f3c4d86cca8a	2aa10772-1ca4-4aa3-9da7-320060eeb518	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
9afb2f29-77f5-4a73-9e1f-2575c4bc75ee	HK1	1	2aa10772-1ca4-4aa3-9da7-320060eeb518	1573aa30-7bfc-44fd-bbaf-95c64e06ba96	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
c65f2d50-5524-426e-b79e-1245f914971b	HK1	1	ead9dc42-f8d2-4959-a943-75da6fd02041	ad8c5e96-5fef-47a4-b907-5122eb0504d2	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
0df8bf23-3e06-4c96-9e5a-9b9d00aafae8	HK1	1	ad8c5e96-5fef-47a4-b907-5122eb0504d2	0c33297a-de3b-4143-947b-f71cc3a8ed21	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
c734984b-3dd4-4166-902b-11edc344d7d0	HK1	1	0c33297a-de3b-4143-947b-f71cc3a8ed21	2c154955-4cc4-43c3-a740-1e97e289b5f7	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
b47a296b-51f6-40db-9dff-5a2b637da652	HK1	1	2c154955-4cc4-43c3-a740-1e97e289b5f7	69e0fc9e-6456-417c-834e-6f5921a3ea9f	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
6bbd4d57-47f9-42d3-a4eb-2a0c8183552d	HK1	1	69e0fc9e-6456-417c-834e-6f5921a3ea9f	423090c9-8806-4645-ab82-7eb9cb4a6dbe	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
2788497f-0f91-4153-9b1a-b955fab137dc	HK1	1	423090c9-8806-4645-ab82-7eb9cb4a6dbe	6eaa3bd6-2721-4048-a0a4-4ac9ace0ba3d	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
550169e8-716a-40ea-9e01-b2cd084d884d	HK1	1	6eaa3bd6-2721-4048-a0a4-4ac9ace0ba3d	36d39803-4327-41ff-a77c-2cfa06e8fff1	2026-08-08 10:23:02.907332+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:23:02.907332+00
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "ngay_cap_nhat", "nam_hoc", "createdat", "updatedat", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "giai_thich") FROM stdin;
1	BGH	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
2	BGH	qlchidoan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
3	BGH	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
4	BGH	ptdoanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
5	BGH	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
6	BGH	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
7	BGH	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
8	BGH	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
9	BGH	baocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
10	BGH	tonghopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
11	BGH	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
12	BGH	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
13	BGH	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
14	BGH	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
15	BTV	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
16	BTV	qlchidoan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
18	BTV	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
19	BTV	ptdoanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
20	BTV	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
21	BTV	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
22	BTV	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
23	BTV	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
24	BTV	baocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
25	BTV	tonghopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
26	BTV	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
27	BTV	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
28	BTV	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	t	f	
29	BTV	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
31	BCH	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
32	BCH	qlchidoan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	t	f	
34	BCH	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	t	f	
35	BCH	ptdoanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
36	BCH	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
37	BCH	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
39	BCH	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
40	BCH	baocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
41	BCH	tonghopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
42	BCH	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
43	BCH	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
44	BCH	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	t	f	
45	BCH	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
46	GVCN	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
47	GVCN	qlchidoan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
50	GVCN	ptdoanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
51	GVCN	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
52	GVCN	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
53	GVCN	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
54	GVCN	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
55	GVCN	baocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
56	GVCN	tonghopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
57	GVCN	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
58	GVCN	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
59	GVCN	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
60	GVCN	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
61	NC	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
62	NC	qlchidoan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
63	NC	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
64	NC	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
65	NC	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
66	NC	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
67	NC	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
68	NC	baocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
69	NC	tonghopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
70	NC	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
71	NC	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
72	NC	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	t	f	
73	NC	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
74	DV	tongquan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
76	DV	ptdoanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
77	DV	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
78	DV	phancong	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
79	DV	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
80	DV	namtuan	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
81	DV	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
49	GVCN	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-14 15:02:47.628675+00	t	f	f	f	
75	DV	doanvien	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-14 15:02:47.628675+00	t	f	f	f	
38	BCH	chamdiem	2026-08-14 18:31:18.325539+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-14 18:31:18.325539+00	t	f	f	f	
82	DV	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
83	DV	theodoi360	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	t	t	t	
84	DV	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
85	PH	tieuchitd	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
86	PH	chamdiem	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
87	PH	qlbaocao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
88	PH	qlnopbc	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
89	PH	thongbao	2026-08-08 10:21:40.434+00	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:21:39.512487+00	2026-08-08 10:21:39.512487+00	t	f	f	f	
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."push_subscriptions" ("id", "user_id", "role", "chidoan_id", "subscription", "endpoint", "created_at") FROM stdin;
\.


--
-- Data for Name: ql_baocao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_baocao" ("id", "chu_de", "chu_de_phu", "tu_ngay", "den_ngay", "cho_phep_minh_chung", "doi_tuong_nop", "huong_dan", "ngay_tao", "nam_hoc_id", "hoc_ky", "config_noi_dung1", "config_noi_dung2", "config_noi_dung3", "config_noi_dung4", "config_noi_dung5", "config_noi_dung6", "config_noi_dung7", "config_noi_dung8", "config_noi_dung9", "config_noi_dung10", "allowed_file_types", "max_file_size") FROM stdin;
\.


--
-- Data for Name: ql_nop_bc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_nop_bc" ("id", "ql_bao_cao_id", "doanvien_id", "noi_dung1", "noi_dung2", "noi_dung3", "noi_dung4", "noi_dung5", "noi_dung6", "noi_dung7", "noi_dung8", "noi_dung9", "noi_dung10", "duong_dan_minh_chung", "ghi_chu", "trang_thai", "ngay_capnhat", "chi_doan_id", "danh_sach_anh", "vaitro_nop", "doituong_nop", "nguoi_tao_id") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat", "he_so_tru", "he_so_cong") FROM stdin;
47ebde83-9919-4bee-919c-05f26d5462c9	10A6	Chiều	NC	6	\N	Trần Thọ Tiến	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:14:54.333065+00	2026-08-08 10:22:07.311365+00	1	1
03185d94-5054-4656-a38e-0dfeea80e000	10A7	Chiều	CB	7		Nguyễn Thị Thùy	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:15:09.462451+00	2026-08-08 10:22:07.311365+00	1	1
d4b09703-b71d-43f4-8bf8-8113993d052c	10A8	Chiều	CB	8	\N	Huỳnh Thị Mỹ Hoa	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:15:28.319565+00	2026-08-08 10:22:07.311365+00	1	1
c833c350-b573-4008-8408-dc3246bfbf57	11A2	Sáng	CB	14	Lê Hồ Thanh Trúc	Huỳnh Thị Thanh Thủy	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:03.775451+00	2026-08-08 10:22:07.311365+00	1	1
8bab981f-6595-422a-8ef8-531a8ad2dc6c	11A1	Sáng	NC	13	Nguyễn Thị Thảo Nguyên	Đỗ Thị Tuyết	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:10.294125+00	2026-08-08 10:22:07.311365+00	1	1
36d39803-4327-41ff-a77c-2cfa06e8fff1	12A8	Sáng	NC	8	Đoàn Thanh Nhi	Lê Thị Minh Huế	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:19.157139+00	2026-08-08 10:22:07.311365+00	1	1
6eaa3bd6-2721-4048-a0a4-4ac9ace0ba3d	12A7	Sáng	CB	7	Minh Tuyết		c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:24.654657+00	2026-08-08 10:22:07.311365+00	1	1
1a901841-c865-4075-b751-709e6e07fc24	11A3	Sáng	CB	15	Lê Thị Thùy Dương	Nguyễn Thị Thanh Phương	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:47.826919+00	2026-08-08 10:22:07.311365+00	1	1
65afb55f-0a15-49b8-b3a0-e854ca89c6c9	11A4	Sáng	CB	16	Quang Phúc	Nguyễn Thị Hiền	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:06:55.820137+00	2026-08-08 10:22:07.311365+00	1	1
5a5d6f62-ea63-40dc-a979-41deb2a4b128	11A5	Sáng	CB	1	Trần Thanh Trúc	Mai Văn Bình	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:07:03.231756+00	2026-08-08 10:22:07.311365+00	1	1
2aa10772-1ca4-4aa3-9da7-320060eeb518	11A7	Chiều	CB	3	Trung Quyên	Vũ Thị Thu Hương	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:07:15.796874+00	2026-08-08 10:22:07.311365+00	1	1
cfe67912-0227-4c03-a869-f3c4d86cca8a	11A6	Chiều	NC	2	Thanh Nhàn	Phan Thanh Hòa	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:07:25.750026+00	2026-08-08 10:22:07.311365+00	1	1
1573aa30-7bfc-44fd-bbaf-95c64e06ba96	11A8	Chiều	CB	4	Võ Hà Khánh Thy	Nguyễn Thị Thanh	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:07:32.864021+00	2026-08-08 10:22:07.311365+00	1	1
ead9dc42-f8d2-4959-a943-75da6fd02041	12A1	Sáng	CB	1	Nguyễn Đặng Mỹ Duyên	Võ Thị Thu Hà	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:07:42.426932+00	2026-08-08 10:22:07.311365+00	1	1
0c33297a-de3b-4143-947b-f71cc3a8ed21	12A3	Sáng	CB	3	Phạm Văn Tình	\N	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:08:19.053804+00	2026-08-08 10:22:07.311365+00	1	1
2c154955-4cc4-43c3-a740-1e97e289b5f7	12A4	Sáng	CB	4	Lê Minh Kiên	\N	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:08:24.793105+00	2026-08-08 10:22:07.311365+00	1	1
69e0fc9e-6456-417c-834e-6f5921a3ea9f	12A5	Sáng	CB	5	Phạm Công Tĩnh	Phạm Thị Giang	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:08:31.375601+00	2026-08-08 10:22:07.311365+00	1	1
423090c9-8806-4645-ab82-7eb9cb4a6dbe	12A6	Sáng	CB	6	Đặng Hoàng Nhật	Trần Thị Minh Phượng	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:08:38.530992+00	2026-08-08 10:22:07.311365+00	1	1
ad8c5e96-5fef-47a4-b907-5122eb0504d2	12A2	Sáng	NC	2	Nguyễn Thùy Dương	Nguyễn Thị Kim Duy	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:10:04.669877+00	2026-08-08 10:22:07.311365+00	1	1
9415a0de-ce74-44f1-8ab1-3363150d20e0	10A1	Chiều	NC	1		Hà Thị Hồng Vị	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:10:45.817436+00	2026-08-08 10:22:07.311365+00	1	1
c5811224-0c82-4f88-b226-de43be7e3ba3	10A2	Chiều	CB	2		Đinh Thị Khánh Ngọc	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:13:57.521813+00	2026-08-08 10:22:07.311365+00	1	1
3e148a67-e9e3-4c3b-8053-5f3760d91f6a	10A3	Chiều	CB	3		Trần Thị Việt Anh	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:14:11.570271+00	2026-08-08 10:22:07.311365+00	1	1
67610cc7-fc8d-427f-a761-a287e6684a68	10A4	Chiều	CB	4		Lê Thị Thanh Xuân	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:14:23.188197+00	2026-08-08 10:22:07.311365+00	1	1
b7129033-6e18-42fa-ba97-0583d1dab51a	10A5	Chiều	CB	5		Mai Văn Bình	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-14 01:14:31.932965+00	2026-08-08 10:22:07.311365+00	1	1
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat", "cloudinary_cloud_name", "cloudinary_upload_preset", "cloudinary_api_key", "cloudinary_api_secret", "r2_account_id", "r2_access_key_id", "r2_secret_access_key", "r2_bucket_name", "r2_custom_domain", "show_class_select_gvcn", "diem_tot", "diem_kha", "diem_tb", "diem_yeu", "ti_trong_diem_tuan", "ti_trong_diem_hoc_tap") FROM stdin;
4ae5c16b-f2dc-4bc1-926f-f01464c46cf5	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Mạc Đỉnh Chi	100		AQ.Ab8RN6L7WL5i-SpEuDED8xuEMKn_0xefViEiDFn63WZDT7Wp7Q	100		\N	\N	\N	\N	23:55	30	Lỗi không báo cáo điểm tuần	f	Hệ thống tự động	0		[C]ĐOÀN XÃ CHƯ PĂH\n[C][B]ĐOÀN TRƯỜNG THPT MẠC ĐĨNH CHI\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Chư Păh, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{THÁI THỊ THU HÀ}}	[C]ĐOÀN XÃ CHƯ PĂH\n[C][B]ĐOÀN TRƯỜNG THPT MẠC ĐĨNH CHI\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Chư Păh, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{THÁI THỊ THU HÀ}}	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:02:45.218815+00	2026-08-08 14:06:12.98832+00					bfa0d861092129fbb580ecbcab565fbc	74e6a5239091aecade32d5828853f476	12363f9228b99fbf268dad55f2aefbdcc31d17a2a2eb8b6c9b5a693845c70b6a	gialaithptmacdinhchi	https://pub-69e062b4d8f245bfb37ee42cfe9a78e3.r2.dev	Không hiển thị	10	7	4	1	50	50
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat", "doanvien_id", "sl_dangnhap", "tg_truycap") FROM stdin;
14fb9fa5-1241-411e-8fd8-41f8d3d7635a	buicaokhadan	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	BÙI CAO KHẢ DÂN	DV	2026-08-11 13:25:45.200573+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	6a417cab-4077-48e0-be69-0cd6c3ccaf52	1	2026-08-11 20:25:45+00
cb8e9840-f74e-4c00-b930-9afce0b12945	Admin	$argon2id$v=19$m=65536,t=3,p=4$PUDXJllthdBNREj7Jd2KTw$blk3GJ2W6Jk/+OxXqPO9quBJtU9mjQqcHb6rYNmBxjM	Quản trị	Admin	2026-08-14 01:04:12.986334+00	\N	2026-08-08 08:45:00.85378+00	\N	4	2026-08-14 08:04:13+00
91576a29-5b66-4f8e-bad5-844b613d9ee9	vuphuongthuyan	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	VŨ PHƯƠNG THÙY AN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	5d8b59f1-d2c2-4a3a-9da3-0843b2625136	0	\N
5a7008e9-1450-45e7-a7b1-0ccac8887a70	buivutramanh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	BÙI VŨ TRÂM ANH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	83a44971-4e7e-487c-852a-20867a546ca9	0	\N
6d7d3b57-92eb-4112-bae4-d6b4a2df11d5	duongquynhanh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	DƯƠNG QUỲNH ANH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	d9bfe50a-841e-45a5-8377-ca3b93ac6ca7	0	\N
aae56922-453b-4c7f-9c50-5ab645451c46	nguyennhatanh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN NHẬT ANH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	7be47ffd-e191-4ec0-ac17-d9c0ff21bfed	0	\N
de18d7a3-d9cd-43e4-a3f5-5d67719817aa	trinhquynhanh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRỊNH QUỲNH ANH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	37bbf19b-63f3-494a-bc4a-4f2141d339d5	0	\N
8c379094-400e-4b4b-b4f0-e1851151a1e8	dovietdung	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	ĐỖ VIỆT DŨNG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	cb91134d-343c-46ef-a71b-cadeb7270998	0	\N
04fd0dc5-636f-4bd0-bb3e-6109b0c81d18	nguyentranxuandung	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN TRẦN XUÂN DŨNG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	1ca94bac-78d4-4c14-8daf-c51b97da8704	0	\N
51f12be3-2b88-4077-b597-e8ebdc86dc8b	letranbaoduy	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	LÊ TRẦN BẢO DUY	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	8bf7bff6-12bf-452d-9cc4-f18b855316e1	0	\N
0c38f9c1-f4ad-48d8-bf8c-6acce2e7ba29	nguyentienhai	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN TIẾN HẢI	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	6033ca2f-db5b-461f-8e44-e1dba461f61f	0	\N
e536b612-30ad-468b-a4b1-3e4c90deb983	huynhnhatbaohan	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	HUỲNH NHẬT BẢO HÂN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	f78b3155-084f-446b-8af0-15e03165562f	0	\N
68e85ac0-27ce-44e5-8b0e-913087e37696	huynhthingochieu	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	HUỲNH THỊ NGỌC HIẾU	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	4ed6c5fc-38ab-424e-93bd-01b93edab589	0	\N
129ba017-c429-4cc7-9a31-1570517a16f5	nguyenduchuy	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN ĐỨC HUY	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	597e5ea9-f6ab-44c4-9b84-041262e21d8d	0	\N
272a503e-66c8-444b-b63c-0ee59f7a6ff9	tranduchuy	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRẦN ĐỨC HUY	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	b33c3d16-8189-4121-8ba3-aac6b31cf237	0	\N
d305711a-1c5e-4bb4-984b-adb45afe4d64	nguyenminhkhang	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN MINH KHANG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	a0b1ce6f-ddec-4f48-a148-682738a85cc0	0	\N
d092b97f-c23b-4445-be5a-6e726079abc8	nguyenvinhkhang	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN VĨNH KHANG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	ee59870a-3adc-4a78-9b81-52071bb0385e	0	\N
1646bf74-0c23-400e-8a57-dfb1f11ede53	phamduykhang	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	PHẠM DUY KHANG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	f84fd2d2-d01b-46d1-b97b-381b93b1c4c9	0	\N
0b0dd682-4b52-4ccf-accc-6a28293f7498	tranngoctukhue	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRẦN NGỌC TÚ KHUÊ	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	a63fb241-43fe-4a62-8e65-25947256b357	0	\N
40dfb481-c08d-40e9-8d9b-f7cc3a282fa4	trangbaolinh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRANG BẢO LINH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	0596b8f9-133f-4727-a601-07ed9f24a19b	0	\N
8146b9f2-7971-4bed-b862-fe79f1a17f04	nguyendacminh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN ĐẮC MINH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	7d6734d8-807a-4b8f-9b01-5be10b599887	0	\N
18b1abd5-ac3f-43ad-8e4c-1a5c2f7d4aba	dinhthiquynhnga	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	ĐINH THỊ QUỲNH NGA	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	06311517-ae28-4c6f-a273-494d94334610	0	\N
233180f3-2bee-45a7-823b-cf6f10dcb6a5	nguyentranbaonghi	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	Nguyễn Trần Bảo Nghi	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	1f8229f9-a3ba-47bb-9797-47885bda47eb	0	\N
ca78b314-7a72-482a-be6b-26bc23d44218	huynhnhubaongoc	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	HUỲNH NHƯ BẢO NGỌC	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	691b45bd-0766-4311-86b3-32eeb22a725e	0	\N
e5d66c66-1eb5-43ff-bccd-8144a84e7687	nguyenbaongoc	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN BẢO NGỌC	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	84280e93-46ad-463f-9ca1-4daf7ef36d81	0	\N
691876cd-50eb-44dc-b5b5-13296d9f9ae7	phanthihongngoc	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	PHAN THỊ HỒNG NGỌC	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	5c58f10e-b477-4f2f-86ba-471070d82fcc	0	\N
b16dc20c-4345-4eb5-a0ca-7e9cc6242412	tranminhngoc	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRẦN MINH NGỌC	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	9619bb72-6b4c-4d17-b279-369a8a43ad9b	0	\N
f2528d79-03bd-4817-9473-3c1da9cf28f0	vothibaongoc	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	VÕ THỊ BẢO NGỌC	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	41a85b8b-ccfc-496c-910d-657d5fecda38	0	\N
00ffaa3b-f7b0-4c79-b2a1-2e92789492cf	dothithaonguyen	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	ĐỖ THỊ THẢO NGUYÊN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	e1add280-c489-4c24-aff2-55391bb6089e	0	\N
5f33880f-321b-4c56-8435-8bd14c5f5363	nguyentranthaonguyen	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN TRẦN THẢO NGUYÊN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	92baec4a-71f3-4bba-81dd-2e7906b3d8b8	0	\N
b679d41c-18f0-4985-a42e-755140ff4932	phamtrayennhi	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	PHẠM TRÀ YẾN NHI	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	3b4067b7-34c8-463f-a216-3c439f108801	0	\N
9fa167ac-b9c3-47a2-b7c1-05325427e1e3	truongquynhnhu	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRƯƠNG QUỲNH NHƯ	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	46a23fe3-7666-4c01-9e19-458a8b02e6ec	0	\N
9b300d86-80b6-4512-87e5-2f3cb0177381	lehuynhthephong	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	LÊ HUỲNH THẾ PHONG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	9d4a7781-bf2c-481c-b1a4-2a6f1d90a0a5	0	\N
b96c5d93-6c83-407c-9d6e-c9b5cbe96c35	nguyenxuanphu	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN XUÂN PHÚ	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	889ecd6f-e5ee-40be-9b33-76ab73eeaf73	0	\N
48f4a393-f0e8-4f67-9e04-447e7a2357e8	nguyenquynhphuong	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN QUỲNH PHƯƠNG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	f2738caf-76df-4775-9ae3-3880bc08910d	0	\N
62229797-8b39-407c-a0c9-772959f92d18	vokieunhaphuong	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	VÕ KIỀU NHÃ PHƯƠNG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	da6324a2-512c-46ff-9f7a-b4a4825763ec	0	\N
62107379-717d-423f-9d92-8b5a4aa173ea	lenguyenanhquan	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	LÊ NGUYỄN ANH QUÂN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	b6b85d03-3506-4fa8-9790-056c6e1316f4	0	\N
e49c3daf-c6f0-41c7-aaf5-5e88e05ecc63	vothithanhthanh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	VÕ THỊ THANH THANH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	492eb955-d307-434f-bb88-4339ec0b3c9c	0	\N
bcae862a-c63e-4216-b0f5-cf6981a94d23	nguyenthithuthao	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN THỊ THU THẢO	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	be8c439f-8950-4e78-a8f7-89a7f4df0ac6	0	\N
a53b3008-7d58-4a29-b0c9-38e606800c85	nguyentrangthao	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN TRANG THẢO	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	a2f2ab00-8814-4d04-b00a-4fda7a01a78c	0	\N
6dc9d9b9-ce54-4d6c-940b-1e7207a99b42	duongthimythu	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	DƯƠNG THỊ MỸ THƯ	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	740d3ac1-8fbe-47f3-b3a1-8c87c4e25460	0	\N
3408fc13-8c15-4e72-ada9-b24c19461fd1	daotrananhthu	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	ĐÀO TRẦN ANH THƯ	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	1dd91cb7-b076-4da5-8d3a-4ab94dae1559	0	\N
86dff5ef-d607-4e6b-8f13-50e8e9bd827f	trieutantien	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRIỆU TẤN TIẾN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	fa8e89be-dd38-4ef8-be68-82d2dc933818	0	\N
094e3fc6-27bf-411c-b657-ff67503b5151	lequachthuytrang	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	LÊ QUÁCH THÙY TRANG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	5840e272-927e-46ff-baee-485319e56906	0	\N
0a45e0a2-5ab8-4dbc-a8d6-cfa45d91a8b7	nguyenthingoctuong	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN THỊ NGỌC TƯỜNG	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	9d319e23-1472-4c57-8d54-de9a18ed5f3e	0	\N
c1fa7271-37f7-4c87-902e-2bb0a4966a73	tranhoangthuuyen	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	TRẦN HOÀNG THU UYÊN	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	bbe9c9af-8e4f-44cb-a5d8-6d4407de5f6f	0	\N
7cdce5b0-ef97-42f7-aac7-4ae6e192245a	vuquocviet	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	VŨ QUỐC VIỆT	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	f83dc4e9-cd20-4150-a0cd-2df28d4b1232	0	\N
4d26b53e-0523-4985-bec7-167e1634e186	nguyencongvinh	$argon2id$v=19$m=65536,t=3,p=4$gBZJ1l8urgUUgEgHgik7ig$dBCiDKG/dxMIgf+bffLmNNsPX6cQloPKtPr+W2DFc60	NGUYỄN CÔNG VINH	DV	2026-08-11 13:23:19.003966+00	8bab981f-6595-422a-8ef8-531a8ad2dc6c	2026-08-11 13:23:19.003966+00	b184fe79-36a4-442c-add1-ef7ec9b6cd07	0	\N
\.


--
-- Data for Name: theodoi360; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."theodoi360" ("id", "nguoi_to_cao_id", "doan_vien_vi_pham_id", "tieu_chi_id", "chi_tiet_vi_pham", "danh_sach_hinh_anh", "url_video", "trang_thai", "nam_hoc_id", "tuan_id", "ngay_vi_pham", "ngay_tao", "hoc_ky", "phan_hoi_bi_to_cao", "phan_hoi_lop", "minh_chung_drive") FROM stdin;
\.


--
-- Data for Name: thongbao_hethong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_hethong" ("id", "title", "content", "sender", "target_role", "target_chidoan_id", "target_user_id", "created_at", "read_by") FROM stdin;
\.


--
-- Data for Name: thongbao_riengbiet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_riengbiet" ("id", "namhoc_id", "sender_id", "sender_name", "sender_role", "title", "content", "attachments", "target_roles", "target_chidoan_ids", "start_at", "end_at", "created_at", "updated_at", "read_by") FROM stdin;
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
c6eee17c-7abe-4a4b-a644-fd8d595631b3	CD01	Điểm 10		Thành tích	0	3		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
7b11746b-135e-4461-a99e-78faaed61da4	CD02	Điểm 9		Thành tích	0	2		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
dfa5deb3-5156-4b52-aadf-54a23e846708	CD03	Nhặt được của rơi		Thành tích	0	5		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
a1200330-44e3-4efe-94db-d2f639530027	TC01	Đi học muộn2		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
60cf244b-f3a8-4038-a583-f8002790ed64	TC02	Cúp tiết		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
094868ed-2878-480c-ab71-8765860931b5	TC03	Cúp chào cờ		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
65b6ec7d-4c71-491d-b8bb-80f12994c172	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
9432d112-bfc8-45fe-9e0b-56cd1b1bbfa2	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
2b5ce382-65a8-4f81-a32c-528ed83fa7e0	TC06	Không sơ vin		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
09fbedc0-954b-4b42-86b1-7334ee1d0897	TC07	Không bảng tên		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
a7cc9e25-e262-42fa-a2a4-fffef497ee52	TC08	Sai đồng phục		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
9b3c9f33-3275-4f86-90c1-d494d629e33a	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
71171da7-86ff-49af-854e-c486179543ae	TC10	Không quai dép		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
9052e9ef-bb2d-44f6-a544-36d3262e90d3	TC11	Đi dép lê		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
a2aeec12-6755-41bc-bb62-229fc9d47a19	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b7ee2664-5de1-42ee-8ed7-210842e779b8	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
483ed2a2-8811-476e-b857-0f7fab879a3c	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b33c0225-0673-42af-b5d0-781734867d55	TC15	Sơn móng tay		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b05b0c64-6789-4a0c-ba92-fe3ef56781dc	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b7a79c49-c427-492b-abbf-ff14675c3451	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
d1e1a4da-9e09-4c0b-8e29-fb782334e285	TC18	chở quá số người qui định		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
7de7af93-65ff-4214-b11b-aa5e1284d2aa	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
abe8c2d4-4533-41a6-a3e2-df851826b292	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
2ad78b94-592e-4311-a010-21790de83988	TC21	Hút thuốc lá		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
c3e3e30a-b6ce-4f6d-aa67-593d43d26225	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
d9ed9277-b31b-467a-8680-373e982df4d1	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
09b86a2f-c337-4763-b420-0ae312877421	TC24	Có thái độ vô lễ với CB, CNV nhà trường:		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
ecc64606-39c7-4234-8fd0-5bdcc3b12a1f	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
731f7e46-169f-42ce-90a5-62bf997b3707	TC26	Vệ sinh muộn		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b66982eb-c915-4a96-a4d8-3f6b2ee0c04d	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
93a877c5-ecdc-46c8-b8b8-6a8eedb695a0	TC28	Học sinh vứt rác không đúng qui định		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
7962d48d-fbfd-4299-b0d1-c74d21d31f06	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
fc91e435-ae33-4efa-af45-789f02730867	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
ff1410ec-ece5-460b-aa06-dd5c25d2c298	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
4685c19d-014c-4a3d-927d-f770f99a6339	TC32	Không cất ghế ngồi chào cờ		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
cf9ec3f1-505f-4e64-8882-ed06373fb262	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
9e828e27-bd56-4a96-ab5d-9fbba4701e72	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
3f03e3d1-305e-4869-b103-d7663368709c	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
ca696d9e-a051-43fd-bb13-574e5c065082	TC36	Học sinh vào lớp muộn trong giữa các tiết học		Vi phạm	0.5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
75a6b68e-c3dc-4fd6-8c83-e183ac56ed6c	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
30f4320d-9725-435f-8c94-126caddb4d6a	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
9e10d03a-75c2-4d2c-822d-02758cc8e6a7	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
74b0b471-4d34-478f-9150-9065fe3a0742	TC40	Đi chấm trễ		Vi phạm	2	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
044fe3d1-5b5a-4b95-b944-1ec64d4ed83d	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
91c25234-7c05-41fd-950b-18450d44b5f3	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
f28d47b4-f83a-4eea-bc1c-e6328a580fc2	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b6726561-2da8-4c36-8b85-147a5a7cb5a8	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
d2696cb2-ea6b-4579-a5fd-d9aecf02ffec	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
6cc13581-da44-4b25-af76-e7a13b49f8f9	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
af981c30-13ec-4d4e-b38a-4419740829e9	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
b19593e8-3def-4a05-a49d-3b1945220f09	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
97bc30a6-04c2-47a4-8517-9cad7475f322	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
cd835e79-becb-474a-a64e-2e6c7dd26e1a	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
2346bf20-888f-4822-bab3-f2cc2b2d6fb9	TC52	Không đi chấm		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
899f6113-1a65-44d6-ac0f-46707e012feb	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
0b83e3ce-28ed-40c0-9235-516167e5d5fe	TC56	Cúp 1 tiết		Vi phạm	5	0		2026-08-08 10:22:48.101855+00	HK1	c62f3a9d-ad68-4927-a949-8f4b6f3575be	2026-08-08 10:22:48.101855+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
4ec44d09-025e-4ee4-815a-84d8df39d68c	c62f3a9d-ad68-4927-a949-8f4b6f3575be	HK1	1	2026-08-03	2026-11-21	t	f	2026-08-08 10:02:23.420408+00		2026-08-08 10:02:45.489416+00
\.


--
-- Data for Name: xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."xet_thidua" ("id", "namhoc_id", "hoc_ky", "chidoan_id", "tong_diem_cham_tuan", "tieuchi_1", "tieuchi_2", "tieuchi_3", "tieuchi_4", "tieuchi_5", "tieuchi_6", "tieuchi_7", "tieuchi_8", "tieuchi_9", "tieuchi_10", "tong_diem", "xep_hang", "danh_hieu_thi_dua", "ghi_chu", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_11" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_12" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_13; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_13" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_14; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_14" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_15; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_15" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_16; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_16" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_17; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_17" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-08-08 08:43:57
20211116045059	2026-08-08 08:43:57
20211116050929	2026-08-08 08:43:57
20211116051442	2026-08-08 08:43:57
20211116212300	2026-08-08 08:43:57
20211116213355	2026-08-08 08:43:57
20211116213934	2026-08-08 08:43:57
20211116214523	2026-08-08 08:43:57
20211122062447	2026-08-08 08:43:57
20211124070109	2026-08-08 08:43:57
20211202204204	2026-08-08 08:43:57
20211202204605	2026-08-08 08:43:57
20211210212804	2026-08-08 08:43:57
20211228014915	2026-08-08 08:43:57
20220107221237	2026-08-08 08:43:57
20220228202821	2026-08-08 08:43:57
20220312004840	2026-08-08 08:43:57
20220603231003	2026-08-08 08:43:57
20220603232444	2026-08-08 08:43:57
20220615214548	2026-08-08 08:43:57
20220712093339	2026-08-08 08:43:57
20220908172859	2026-08-08 08:43:57
20220916233421	2026-08-08 08:43:57
20230119133233	2026-08-08 08:43:57
20230128025114	2026-08-08 08:43:57
20230128025212	2026-08-08 08:43:57
20230227211149	2026-08-08 08:43:57
20230228184745	2026-08-08 08:43:57
20230308225145	2026-08-08 08:43:57
20230328144023	2026-08-08 08:43:57
20231018144023	2026-08-08 08:43:57
20231204144023	2026-08-08 08:43:57
20231204144024	2026-08-08 08:43:57
20231204144025	2026-08-08 08:43:57
20240108234812	2026-08-08 08:43:57
20240109165339	2026-08-08 08:43:57
20240227174441	2026-08-08 08:43:57
20240311171622	2026-08-08 08:43:57
20240321100241	2026-08-08 08:43:57
20240401105812	2026-08-08 08:43:57
20240418121054	2026-08-08 08:43:57
20240523004032	2026-08-08 08:43:57
20240618124746	2026-08-08 08:43:57
20240801235015	2026-08-08 08:43:57
20240805133720	2026-08-08 08:43:57
20240827160934	2026-08-08 08:43:57
20240919163303	2026-08-08 08:43:57
20240919163305	2026-08-08 08:43:57
20241019105805	2026-08-08 08:43:57
20241030150047	2026-08-08 08:43:57
20241108114728	2026-08-08 08:43:57
20241121104152	2026-08-08 08:43:57
20241130184212	2026-08-08 08:43:57
20241220035512	2026-08-08 08:43:57
20241220123912	2026-08-08 08:43:57
20241224161212	2026-08-08 08:43:57
20250107150512	2026-08-08 08:43:57
20250110162412	2026-08-08 08:43:57
20250123174212	2026-08-08 08:43:57
20250128220012	2026-08-08 08:43:57
20250506224012	2026-08-08 08:43:57
20250523164012	2026-08-08 08:43:57
20250714121412	2026-08-08 08:43:57
20250905041441	2026-08-08 08:43:57
20251103001201	2026-08-08 08:43:57
20251120212548	2026-08-08 08:43:57
20251120215549	2026-08-08 08:43:57
20260218120000	2026-08-08 08:43:57
20260326120000	2026-08-08 08:43:57
20260514120000	2026-08-08 08:43:57
20260527120000	2026-08-08 08:43:57
20260528120000	2026-08-08 08:43:57
20260603120000	2026-08-08 08:43:57
20260605120000	2026-08-08 08:43:57
20260606110000	2026-08-08 08:43:57
20260616120000	2026-08-08 08:43:57
20260624120000	2026-08-08 08:43:57
20260626120000	2026-08-08 08:43:57
20260706120000	2026-08-08 08:43:57
20260707120000	2026-08-08 08:43:57
20260709120000	2026-08-08 08:43:57
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-08-08 07:20:21.702184
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-08-08 07:20:21.745016
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-08-08 07:20:21.750467
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-08-08 07:20:21.773294
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-08-08 07:20:21.787774
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-08-08 07:20:21.793544
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-08-08 07:20:21.799363
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-08-08 07:20:21.805431
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-08-08 07:20:21.810889
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-08-08 07:20:21.816468
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-08-08 07:20:21.821973
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-08-08 07:20:21.828636
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-08-08 07:20:21.834461
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-08-08 07:20:21.839989
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-08-08 07:20:21.845501
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-08-08 07:20:21.872862
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-08-08 07:20:21.878477
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-08-08 07:20:21.883858
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-08-08 07:20:21.889308
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-08-08 07:20:21.896203
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-08-08 07:20:21.903334
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-08-08 07:20:21.910563
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-08-08 07:20:21.926686
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-08-08 07:20:21.937776
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-08-08 07:20:21.94352
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-08-08 07:20:21.949129
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-08-08 07:20:21.954864
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-08-08 07:20:21.960237
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-08-08 07:20:21.965374
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-08-08 07:20:21.970814
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-08-08 07:20:21.976
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-08-08 07:20:21.981447
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-08-08 07:20:21.986928
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-08-08 07:20:21.992314
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-08-08 07:20:21.998025
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-08-08 07:20:22.003571
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-08-08 07:20:22.00957
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-08-08 07:20:22.015265
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-08-08 07:20:22.021682
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-08-08 07:20:22.034078
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-08-08 07:20:22.039696
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-08-08 07:20:22.045164
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-08-08 07:20:22.050625
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-08-08 07:20:22.056216
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-08-08 07:20:22.061854
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-08-08 07:20:22.068123
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-08-08 07:20:22.080337
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-08-08 07:20:22.086426
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-08-08 07:20:22.092176
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-08-08 07:20:22.11008
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-08-08 07:20:22.116981
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-08-08 07:20:22.136307
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-08-08 07:20:22.13845
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-08-08 07:20:22.149424
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-08-08 07:20:22.154804
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-08-08 07:20:22.157005
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-08-08 07:20:22.163945
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-08-08 07:20:22.171003
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-08-08 07:20:22.176948
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-08-08 07:20:22.183723
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-08-08 07:20:22.189765
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-11 13:20:28.076909
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 14, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 89, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: gio_hoc_tap gio_hoc_tap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "gio_hoc_tap_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_endpoint_key" UNIQUE ("endpoint");


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_pkey" PRIMARY KEY ("id");


--
-- Name: ql_baocao ql_baocao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "ql_baocao_pkey" PRIMARY KEY ("id");


--
-- Name: ql_nop_bc ql_nop_bc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "ql_nop_bc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: theodoi360 theodoi360_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_hethong thongbao_hethong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_hethong"
    ADD CONSTRAINT "thongbao_hethong_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_riengbiet thongbao_riengbiet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "thongbao_riengbiet_pkey" PRIMARY KEY ("id");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua unique_cauhinh_namhoc_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "unique_cauhinh_namhoc_hocky" UNIQUE ("namhoc_id", "hoc_ky");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: gio_hoc_tap unique_chidoan_tuan_namhoc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "unique_chidoan_tuan_namhoc" UNIQUE ("chidoan_id", "tuan_id", "namhoc_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: xet_thidua unique_xet_thidua_chidoan_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "unique_xet_thidua_chidoan_hocky" UNIQUE ("namhoc_id", "hoc_ky", "chidoan_id");


--
-- Name: xet_thidua xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_11 messages_2026_08_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_11"
    ADD CONSTRAINT "messages_2026_08_11_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_12 messages_2026_08_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_12"
    ADD CONSTRAINT "messages_2026_08_12_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_13 messages_2026_08_13_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_13"
    ADD CONSTRAINT "messages_2026_08_13_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_14 messages_2026_08_14_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_14"
    ADD CONSTRAINT "messages_2026_08_14_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_15 messages_2026_08_15_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_15"
    ADD CONSTRAINT "messages_2026_08_15_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_16 messages_2026_08_16_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_16"
    ADD CONSTRAINT "messages_2026_08_16_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_17 messages_2026_08_17_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_17"
    ADD CONSTRAINT "messages_2026_08_17_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_cauhinh_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_cauhinh_thidua_namhoc_hocky" ON "public"."cauhinh_tieuchi_xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: idx_chamdiem_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_hocky" ON "public"."chamdiem" USING "btree" ("hocky");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_lopcham_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_lopcham_chamlop" ON "public"."chamdiem" USING "btree" ("lopcham", "chamlop");


--
-- Name: idx_chamdiem_optimization_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_optimization_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_optimization_namhoc_hocky_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_hocky_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_chamdiem_optimization_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "tuan");


--
-- Name: idx_chamdiem_thongke; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thongke" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan", "chamlop");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_ql_nop_bc_baocao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_baocao" ON "public"."ql_nop_bc" USING "btree" ("ql_bao_cao_id");


--
-- Name: idx_ql_nop_bc_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_chidoan" ON "public"."ql_nop_bc" USING "btree" ("chi_doan_id");


--
-- Name: idx_ql_nop_bc_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_doanvien" ON "public"."ql_nop_bc" USING "btree" ("doanvien_id");


--
-- Name: idx_qlchidoan_optimization_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_optimization_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_doanvien_id" ON "public"."taikhoan" USING "btree" ("doanvien_id");


--
-- Name: idx_taikhoan_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_role" ON "public"."taikhoan" USING "btree" ("role");


--
-- Name: idx_taikhoan_username_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_username_lower" ON "public"."taikhoan" USING "btree" ("lower"("username"));


--
-- Name: idx_theodoi360_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_doanvien" ON "public"."theodoi360" USING "btree" ("doan_vien_vi_pham_id");


--
-- Name: idx_theodoi360_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_namhoc_tuan" ON "public"."theodoi360" USING "btree" ("nam_hoc_id", "tuan_id");


--
-- Name: idx_thongbao_riengbiet_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_dates" ON "public"."thongbao_riengbiet" USING "btree" ("start_at", "end_at");


--
-- Name: idx_thongbao_riengbiet_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_namhoc" ON "public"."thongbao_riengbiet" USING "btree" ("namhoc_id");


--
-- Name: idx_thongbao_riengbiet_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_thongbao_riengbiet_sender" ON "public"."thongbao_riengbiet" USING "btree" ("sender_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_optimization_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_optimization_namhoc_hocky" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_xet_thidua_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_chidoan" ON "public"."xet_thidua" USING "btree" ("chidoan_id");


--
-- Name: idx_xet_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_namhoc_hocky" ON "public"."xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_11_inserted_at_topic_idx" ON "realtime"."messages_2026_08_11" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_12_inserted_at_topic_idx" ON "realtime"."messages_2026_08_12" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_13_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_13_inserted_at_topic_idx" ON "realtime"."messages_2026_08_13" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_14_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_14_inserted_at_topic_idx" ON "realtime"."messages_2026_08_14" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_15_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_15_inserted_at_topic_idx" ON "realtime"."messages_2026_08_15" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_16_inserted_at_topic_idx" ON "realtime"."messages_2026_08_16" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_17_inserted_at_topic_idx" ON "realtime"."messages_2026_08_17" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_08_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_11_inserted_at_topic_idx";


--
-- Name: messages_2026_08_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_11_pkey";


--
-- Name: messages_2026_08_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_12_inserted_at_topic_idx";


--
-- Name: messages_2026_08_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_12_pkey";


--
-- Name: messages_2026_08_13_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_13_inserted_at_topic_idx";


--
-- Name: messages_2026_08_13_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_13_pkey";


--
-- Name: messages_2026_08_14_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_14_inserted_at_topic_idx";


--
-- Name: messages_2026_08_14_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_14_pkey";


--
-- Name: messages_2026_08_15_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_15_inserted_at_topic_idx";


--
-- Name: messages_2026_08_15_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_15_pkey";


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_16_inserted_at_topic_idx";


--
-- Name: messages_2026_08_16_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_16_pkey";


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_17_inserted_at_topic_idx";


--
-- Name: messages_2026_08_17_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_17_pkey";


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_chidoan" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_tuan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_tuan" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id") ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ql_baocao fk_ql_baocao_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "fk_ql_baocao_namhoc" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: ql_nop_bc fk_ql_nop_bc_baocao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_baocao" FOREIGN KEY ("ql_bao_cao_id") REFERENCES "public"."ql_baocao"("id") ON DELETE CASCADE;


--
-- Name: ql_nop_bc fk_ql_nop_bc_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_chidoan" FOREIGN KEY ("chi_doan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE SET NULL;


--
-- Name: ql_nop_bc fk_ql_nop_bc_doanvien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_doanvien" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: thongbao_riengbiet fk_thongbao_riengbiet_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "fk_thongbao_riengbiet_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: thongbao_riengbiet fk_thongbao_riengbiet_taikhoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "fk_thongbao_riengbiet_taikhoan" FOREIGN KEY ("sender_id") REFERENCES "public"."taikhoan"("id") ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE SET NULL;


--
-- Name: theodoi360 theodoi360_doan_vien_vi_pham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_doan_vien_vi_pham_fkey" FOREIGN KEY ("doan_vien_vi_pham_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_nam_hoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nam_hoc_fkey" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: theodoi360 theodoi360_nguoi_to_cao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nguoi_to_cao_fkey" FOREIGN KEY ("nguoi_to_cao_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_tieu_chi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tieu_chi_fkey" FOREIGN KEY ("tieu_chi_id") REFERENCES "public"."tieuchitd"("id");


--
-- Name: theodoi360 theodoi360_tuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tuan_fkey" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id");


--
-- Name: xet_thidua xet_thidua_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: xet_thidua xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: doanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."doanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: dotptdoanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."dotptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: namhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."namhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: phancong Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."phancong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ql_baocao Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."ql_baocao" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: qlchidoan Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."qlchidoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tieuchitd Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tieuchitd" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tuanhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tuanhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: thongbao_hethong Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."thongbao_hethong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: xet_thidua Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ptdoanvien Admin, BTV, BCH có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"])));


--
-- Name: thongbao_riengbiet Admin, BTV, BGH, GVCN có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"])));


--
-- Name: chamdiem Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."chamdiem" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: gio_hoc_tap Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: doanvien BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."doanvien" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: qlchidoan BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."qlchidoan" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: duytricsdl Cho phép mọi người cập nhật duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Cho phép mọi người xem duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl" FOR SELECT USING (true);


--
-- Name: github_settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."github_settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: phanquyen Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."phanquyen" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: taikhoan Chỉ Admin được sửa tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa tài khoản" ON "public"."taikhoan" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: github_settings Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."github_settings" FOR SELECT TO "authenticated" USING (true);


--
-- Name: phanquyen Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."phanquyen" FOR SELECT TO "authenticated" USING (true);


--
-- Name: settings Mọi người có thể xem; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem" ON "public"."settings" FOR SELECT TO "authenticated" USING (true);


--
-- Name: taikhoan Mọi người có thể xem tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi người có thể xem tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING (true);


--
-- Name: cauhinh_tieuchi_xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua" FOR SELECT TO "authenticated" USING (true);


--
-- Name: chamdiem Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."chamdiem" FOR SELECT TO "authenticated" USING (true);


--
-- Name: doanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."doanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: dotptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: gio_hoc_tap Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap" FOR SELECT TO "authenticated" USING (true);


--
-- Name: namhoc Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."namhoc" FOR SELECT TO "authenticated" USING (true);


--
-- Name: phancong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."phancong" FOR SELECT TO "authenticated" USING (true);


--
-- Name: ptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien" FOR SELECT TO "authenticated" USING (true);


--
-- Name: ql_baocao Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ql_baocao" FOR SELECT TO "authenticated" USING (true);


--
-- Name: qlchidoan Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."qlchidoan" FOR SELECT TO "authenticated" USING (true);


--
-- Name: thongbao_hethong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong" FOR SELECT TO "authenticated" USING (true);


--
-- Name: thongbao_riengbiet Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet" FOR SELECT TO "authenticated" USING (true);


--
-- Name: tieuchitd Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tieuchitd" FOR SELECT TO "authenticated" USING (true);


--
-- Name: tuanhoc Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tuanhoc" FOR SELECT TO "authenticated" USING (true);


--
-- Name: xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."xet_thidua" FOR SELECT TO "authenticated" USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: duytricsdl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."duytricsdl" ENABLE ROW LEVEL SECURITY;

--
-- Name: gio_hoc_tap; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."gio_hoc_tap" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."push_subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_baocao; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_baocao" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_nop_bc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_nop_bc" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: theodoi360; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."theodoi360" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_hethong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_hethong" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_riengbiet; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_riengbiet" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."activity_logs" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."duytricsdl" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: push_subscriptions Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: ql_nop_bc Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: theodoi360 Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."theodoi360" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "get_auth_chidoan_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_doanvien_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "service_role";


--
-- Name: FUNCTION "get_secure_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "service_role";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "service_role";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "cauhinh_tieuchi_xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "gio_hoc_tap"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "anon";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "authenticated";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "push_subscriptions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."push_subscriptions" TO "anon";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "authenticated";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "service_role";


--
-- Name: TABLE "ql_baocao"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_baocao" TO "anon";
GRANT ALL ON TABLE "public"."ql_baocao" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_baocao" TO "service_role";


--
-- Name: TABLE "ql_nop_bc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_nop_bc" TO "anon";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "theodoi360"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."theodoi360" TO "anon";
GRANT ALL ON TABLE "public"."theodoi360" TO "authenticated";
GRANT ALL ON TABLE "public"."theodoi360" TO "service_role";


--
-- Name: TABLE "thongbao_hethong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_hethong" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "service_role";


--
-- Name: TABLE "thongbao_riengbiet"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."xet_thidua" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_08_11"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_11" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_11" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_12"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_12" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_12" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_13"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_13" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_13" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_14"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_14" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_14" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_15"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_15" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_15" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_16"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_17"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict hvDfkQsRfCen7bE6THot43XInzrfaPILLqXqYGqgKjZ6khZgt0yisbhvBONCW6a

